"""Security primitives for the central RAG registry (E1).

Three concerns, all mandatory per the E0 risk register (R1 SSRF, R2 secrets):

1. **SSRF guard** — provider URLs are validated at write time AND before
   every outbound probe. Blocked by default: cloud metadata (169.254.169.254),
   all link-local ranges, loopback (unless ``allow_loopback``), private
   ranges outside the internal-LAN allowlist, and non-http(s) schemes.
   Redirects are disabled on probes so a blocked target cannot "bounce"
   through an allowed one.

2. **Secret resolver** — ``auth_ref`` is a *reference* (``env:NAME`` or
   ``file:/path``), resolved lazily at call time. The resolved value is
   returned to the caller for use in a request header and is never logged,
   audited or stored.

3. **RBAC** — Bearer tokens map to roles ``admin`` / ``operator`` /
   ``viewer`` (token→role mapping comes from the registry's own config,
   not from a client claim).
"""
from __future__ import annotations

import ipaddress
import re
from dataclasses import dataclass
from typing import Callable
from urllib.parse import urlparse

# ------------------------------------------------------------------ roles

ROLES = ("admin", "operator", "viewer")

#: which actions each role may perform (admin is implicit full access)
ROLE_ACTIONS: dict[str, frozenset[str]] = {
    "viewer": frozenset({"read"}),
    "operator": frozenset({"read", "enable", "disable", "test"}),
    "admin": frozenset({"read", "write", "enable", "disable", "test", "manage_consumers"}),
}


class AuthError(Exception):
    def __init__(self, status: int, code: str, detail: str = "") -> None:
        super().__init__(f"{status} {code}")
        self.status = status
        self.code = code
        self.detail = detail


def role_from_token(tokens: dict[str, str], authorization: str | None) -> str:
    """Map an ``Authorization: Bearer <token>`` header to a role.

    ``tokens`` maps token value → role. Missing/unknown token → 401.
    """
    if not authorization or not authorization.strip():
        raise AuthError(401, "unauthorized", "missing Authorization header")
    m = re.match(r"^Bearer\s+(\S+)$", authorization.strip())
    if not m:
        raise AuthError(401, "unauthorized", "Authorization must be 'Bearer <token>'")
    token = m.group(1)
    role = tokens.get(token)
    if role is None:
        raise AuthError(401, "unauthorized", "unknown token")
    return role


def require(role: str, action: str) -> None:
    if action not in ROLE_ACTIONS.get(role, frozenset()):
        raise AuthError(403, "forbidden", f"role '{role}' may not '{action}'")


def mask_token(token: str | None) -> str:
    """For logs/audit: show at most a 4-char prefix, never the whole value."""
    if not token:
        return ""
    return token[:4] + "***" if len(token) > 4 else "***"


# ------------------------------------------------------------------ SSRF

# Internal LANs that legitimately host RAG providers (AI-TOOLS 172.30.0.0/16,
# s52 172.20.1.0/24, general 10.0.0.0/8). Overridable via config.
DEFAULT_INTERNAL_NETS = ("172.30.0.0/16", "172.20.1.0/24", "10.0.0.0/8")


def _is_blocked_ip(ip: ipaddress.IPv4Address | ipaddress.IPv6Address) -> bool:
    if ip.is_unspecified:
        return True
    # link-local covers 169.254.169.254 (cloud metadata) and IPv6 fe80::/10
    if ip.is_link_local:
        return True
    if ip.is_loopback:
        return True  # loopback handled separately via allow flag
    if ip.is_multicast or ip.is_reserved:
        return True
    return False


class SSRFConfig:
    def __init__(self, allowed_hosts: tuple[str, ...] = (),
                 internal_nets: tuple[str, ...] = DEFAULT_INTERNAL_NETS,
                 allow_loopback: bool = False) -> None:
        self.allowed_hosts = tuple(h.strip().lower() for h in allowed_hosts if h.strip())
        self.allow_loopback = bool(allow_loopback)
        self._nets: list[ipaddress.IPv4Network | ipaddress.IPv6Network] = []
        for net in internal_nets:
            try:
                self._nets.append(ipaddress.ip_network(net, strict=False))
            except ValueError:
                raise ValueError(f"invalid internal net: {net!r}") from None
        # a host allowlist, if present, takes precedence over everything
        self._hosts_exact = set(self.allowed_hosts)

    def _net_for(self, host: str) -> str | None:
        """Return a pinned IP string for a hostname, resolving DNS here so the
        pinned value (not the redirect target) is what the probe dials."""
        import socket

        try:
            infos = socket.getaddrinfo(host, None)
        except socket.gaierror:
            return None
        if not infos:
            return None
        return infos[0][4][0]

    def validate(self, url: str, *, resolve: Callable[[str], str | None] | None = None) -> str:
        """Validate a provider URL. Returns the URL (normalized) or raises
        ``SSRFError`` with a precise reason. DNS is resolved *here* and the
        IP checked, so a hostname pointing at metadata is blocked."""
        if not url or not isinstance(url, str):
            raise SSRFError("url_required", "provider base_url is required")
        try:
            p = urlparse(url)
        except ValueError as e:
            raise SSRFError("bad_url", f"unparseable url: {e}") from None

        if p.scheme not in ("http", "https"):
            raise SSRFError("bad_scheme", f"scheme '{p.scheme}' not allowed (http/https only)")
        if not p.hostname:
            raise SSRFError("bad_url", "url has no host")
        host = p.hostname.rstrip(".").lower()

        # explicit allowlist short-circuits the IP checks (but not scheme/host)
        if self._hosts_exact and (host in self._hosts_exact or
                                  any(host.endswith("." + h) for h in self._hosts_exact)):
            return url

        resolver = resolve or self._net_for
        pinned = None
        if host in ("localhost", "localhost.localdomain"):
            pinned = "127.0.0.1"
        try:
            ip = ipaddress.ip_address(host)
            pinned = str(ip)
        except ValueError:
            pinned = resolver(host)
        if pinned is None:
            raise SSRFError("dns_failed", f"host '{host}' does not resolve")

        try:
            ipobj = ipaddress.ip_address(pinned)
        except ValueError:
            raise SSRFError("bad_ip", f"unparseable resolved address for '{host}'")

        if ipobj.is_loopback:
            if not self.allow_loopback:
                raise SSRFError("loopback_blocked",
                                f"'{host}' resolves to loopback; disabled by policy")
            return url
        if _is_blocked_ip(ipobj):
            raise SSRFError("blocked_ip_range",
                            f"'{host}' resolves to blocked address {pinned}")
        if not any(ipobj in net for net in self._nets):
            raise SSRFError("outside_allowlist",
                            f"{pinned} not in internal allowlist {list(DEFAULT_INTERNAL_NETS)}")
        return url


class SSRFError(Exception):
    def __init__(self, code: str, detail: str) -> None:
        super().__init__(f"{code}: {detail}")
        self.code = code
        self.detail = detail


# ------------------------------------------------------------------ secrets

_SECRET_REF_RE = re.compile(r"^(env|file):[A-Za-z0-9_./\\-]+$")


class SecretError(Exception):
    def __init__(self, code: str, detail: str = "") -> None:
        super().__init__(f"{code}: {detail}" if detail else code)
        self.code = code
        self.detail = detail


def validate_auth_ref(auth_ref: str) -> str:
    """Accept only references, never plaintext secrets.

    Allowed: ``''`` (no auth), ``env:NAME``, ``file:/path/to/secret``.
    """
    if not auth_ref:
        return ""
    if not _SECRET_REF_RE.match(auth_ref):
        raise SecretError("invalid_auth_ref",
                          "auth_ref must be empty, 'env:NAME' or 'file:/path' (never plaintext)")
    if auth_ref.startswith("env:") and not re.match(r"^env:[A-Za-z_][A-Za-z0-9_]*$", auth_ref):
        raise SecretError("invalid_auth_ref", "env name must be a valid identifier")
    return auth_ref


def resolve_secret(auth_ref: str, *,
                   env_lookup: Callable[[str], str | None] | None = None,
                   file_lookup: Callable[[str], str | None] | None = None) -> str:
    """Resolve an ``auth_ref`` to its value at call time.

    ``env_lookup``/``file_lookup`` are injectable for tests. Raises
    :class:`SecretError` when the reference cannot be resolved. The value is
    the caller's responsibility to use transiently; it must never be logged
    or audited.
    """
    if not auth_ref:
        return ""
    if auth_ref.startswith("env:"):
        name = auth_ref[4:]
        lookup = env_lookup or (lambda n: __import__("os").environ.get(n))
        val = lookup(name)
        if val is None or val == "":
            raise SecretError("secret_not_found", f"env var '{name}' is not set")
        return val.strip()
    if auth_ref.startswith("file:"):
        path = auth_ref[5:]
        lookup = file_lookup or _read_file_secret
        val = lookup(path)
        if val is None:
            raise SecretError("secret_not_found", f"secret file '{path}' not readable")
        return val
    raise SecretError("invalid_auth_ref", f"unresolvable ref: {auth_ref[:8]}...")


def _read_file_secret(path: str) -> str | None:
    import os

    try:
        if not os.path.isfile(path):
            return None
        with open(path, encoding="utf-8") as fh:
            return fh.read().strip()
    except OSError:
        return None


def redact_diff(diff: dict) -> dict:
    """Sanitize a diff before it is written to the audit log: any value that
    looks like an ``auth_ref`` stays (it is a reference), but no resolved
    secret ever reaches this function — this is defense in depth against
    accidental plaintext under an ``auth``-like key."""
    out = dict(diff)
    for key in ("api_key", "apikey", "token", "secret", "password", "authorization", "master_key"):
        if key in out:
            out[key] = "***REDACTED***"
    return out
