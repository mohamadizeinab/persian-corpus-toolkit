"""Central RAG Registry (E1).

Single source of truth shared by every UI (Radio, RAG Portal, future admin)
and by the RAG Gateway. Implements the frozen E0 data model and management
API defined in ``docs/architecture/RAG_REGISTRY_AND_CONFIGURATION.md`` plus
the consumer table required by
``docs/architecture/MULTI_RAG_CONSUMER_ARCHITECTURE.md``.

Design rules honoured here:
- additive-only schema (``CREATE TABLE IF NOT EXISTS``), no drops/renames;
- secrets are referenced (``env:NAME`` / ``file:/path``) and resolved at
  call time; they are never stored, echoed, logged or audited;
- SSRF guard on every provider URL (write-time + probe-time);
- RBAC: ``admin`` / ``operator`` / ``viewer`` via Bearer tokens;
- optimistic concurrency via ``updated_at`` (If-Match).
"""

__all__ = ["api", "config", "db", "security", "provider_client"]
