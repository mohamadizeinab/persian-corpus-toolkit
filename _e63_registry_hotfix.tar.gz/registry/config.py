"""Environment-driven configuration for the registry service (E1).

All values come from ``REGISTRY_*`` environment variables so the service can
run identically in tests (local loopback allowed) and on AI-TOOLS (loopback
allowed only for host-local providers such as the mizan/fiqh containers).
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field

from .security import DEFAULT_INTERNAL_NETS, SSRFConfig


@dataclass
class RegistryConfig:
    db_path: str = "/data/rag-registry.db"
    host: str = "0.0.0.0"
    port: int = 8200

    # RBAC: token -> role. Tokens are secrets set in the container env.
    admin_token: str = ""
    operator_token: str = ""
    viewer_token: str = ""

    # SSRF policy
    allowed_hosts: tuple = field(default_factory=tuple)     # e.g. ("rag.ai.ismc.ir",)
    internal_nets: tuple = field(default_factory=lambda: DEFAULT_INTERNAL_NETS)
    allow_loopback: bool = True  # mizan/fiqh providers listen on host loopback

    # consumer key material
    consumer_key_prefix: str = "rc_"

    def tokens(self) -> dict[str, str]:
        out: dict[str, str] = {}
        if self.admin_token:
            out[self.admin_token] = "admin"
        if self.operator_token:
            out[self.operator_token] = "operator"
        if self.viewer_token:
            out[self.viewer_token] = "viewer"
        return out

    def ssrf(self) -> SSRFConfig:
        return SSRFConfig(allowed_hosts=self.allowed_hosts,
                          internal_nets=self.internal_nets,
                          allow_loopback=self.allow_loopback)


def _env(name: str, default: str = "") -> str:
    return os.environ.get(name, default)


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, str(default)))
    except ValueError:
        return default


def _env_bool(name: str, default: bool = False) -> bool:
    v = os.environ.get(name)
    if v is None:
        return default
    return v.strip().lower() in ("1", "true", "yes", "on")


def _env_csv(name: str) -> tuple[str, ...]:
    v = os.environ.get(name, "").strip()
    return tuple(x.strip() for x in v.split(",") if x.strip()) if v else ()


def load_config() -> RegistryConfig:
    return RegistryConfig(
        db_path=_env("REGISTRY_DB_PATH", "/data/rag-registry.db"),
        host=_env("REGISTRY_HOST", "0.0.0.0"),
        port=_env_int("REGISTRY_PORT", 8200),
        admin_token=_env("REGISTRY_ADMIN_TOKEN"),
        operator_token=_env("REGISTRY_OPERATOR_TOKEN"),
        viewer_token=_env("REGISTRY_VIEW_TOKEN"),
        allowed_hosts=_env_csv("REGISTRY_ALLOWED_HOSTS"),
        internal_nets=_env_csv("REGISTRY_INTERNAL_NETS") or DEFAULT_INTERNAL_NETS,
        allow_loopback=_env_bool("REGISTRY_ALLOW_LOOPBACK", True),
        consumer_key_prefix=_env("REGISTRY_CONSUMER_KEY_PREFIX", "rc_"),
    )
