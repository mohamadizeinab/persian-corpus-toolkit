"""Central RAG Registry — shared management API (E1).

Flask app implementing the frozen E0 surface
(``docs/architecture/RAG_REGISTRY_AND_CONFIGURATION.md`` §3) plus consumer
management (``MULTI_RAG_CONSUMER_ARCHITECTURE.md`` §4).

Guarantees honoured:
- **RBAC** on every route (admin / operator / viewer);
- **SSRF** validation at write time and re-validated inside every probe;
- **secrets never echoed**: responses carry only ``auth_ref``; audit diffs
  are redacted;
- **optimistic concurrency**: ``PATCH`` requires ``If-Match: <updated_at>``;
  stale writes → 409 (E0 §8 sync guarantee);
- **audit** on every mutation and on every authz failure (T08 evidence);
- **single active master prompt** per rag_id; activation archives the
  previous version (reversible).
"""
from __future__ import annotations

import functools
import hashlib
import json
import re
import secrets as _pysecrets

from flask import Flask, g, jsonify, request

from . import db as rdb
from . import provider_client as pc
from .config import RegistryConfig
from .security import (AuthError, SSRFError, SecretError, require,
                       redact_diff, role_from_token, validate_auth_ref)

REQUIRED_FIELDS = ("rag_id", "display_name", "provider_type", "base_url",
                   "api_contract_version", "priority", "embedding_model")
PATCHABLE_FIELDS = (
    "rag_name", "display_name", "description", "provider_type", "base_url",
    "api_endpoint", "api_contract_version", "healthcheck_endpoint", "auth_ref",
    "priority", "retrieval_weight", "fallback_priority", "retrieval_config",
    "embedding_model", "vector_index", "top_k", "similarity_threshold",
    "timeout_ms", "retry_policy", "allowed_consumers", "allowed_users",
)
_RAG_ID_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{0,63}$")
_CONSUMER_ID_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{0,63}$")
_ROUTING_POLICIES = ("single", "priority", "fusion")


def _err(status: int, code: str, detail: str = "", **extra):
    body = {"ok": False, "error": code}
    if detail:
        body["detail"] = detail
    body.update(extra)
    return jsonify(body), status


def _ok(payload: dict, status: int = 200):
    return jsonify({"ok": True, **payload}), status


def create_app(cfg: RegistryConfig) -> Flask:
    rdb.init_db(cfg.db_path)
    ssrf = cfg.ssrf()
    app = Flask(__name__)

    # ------------------------------------------------------------- helpers

    def _actor() -> str:
        return g.get("role") or "anonymous"

    def _audit(action: str, rag_id: str | None = None, diff: dict | None = None) -> int:
        with rdb.session(cfg.db_path) as conn:
            return rdb.audit(conn, action, rag_id=rag_id, actor=_actor(),
                             diff=redact_diff(diff or {}))

    def _audit_fail(status: int, code: str,
                    rag_id: str | None = None, detail: str = "") -> None:
        with rdb.session(cfg.db_path) as conn:
            rdb.audit(conn, f"{code}_denied", rag_id=rag_id, actor=_actor(),
                      diff={"status": status, "detail": detail,
                            "path": request.path, "method": request.method})

    def _auth(fn):
        @functools.wraps(fn)
        def wrapper(*a, **k):
            try:
                role = role_from_token(cfg.tokens(), request.headers.get("Authorization"))
                g.role = role
            except AuthError as e:
                _audit_fail(e.status, "unauthorized", detail=e.detail)
                return _err(e.status, e.code, e.detail)
            return fn(*a, **k)
        return wrapper

    def _require(action: str):
        def deco(fn):
            @functools.wraps(fn)
            def wrapper(*a, **k):
                try:
                    require(g.get("role", ""), action)
                except AuthError as e:
                    _audit_fail(e.status, "forbidden",
                                rag_id=request.view_args.get("rag_id"),
                                detail=f"role {g.get('role')} cannot {action}")
                    return _err(e.status, e.code, e.detail)
                return fn(*a, **k)
            return wrapper
        return deco

    def _load(rag_id: str) -> dict | None:
        with rdb.session(cfg.db_path) as conn:
            row = conn.execute(
                "SELECT * FROM rag_providers WHERE rag_id = ?", (rag_id,)
            ).fetchone()
            return rdb.provider_to_dict(row) if row is not None else None

    def _get_provider(rag_id: str):
        """Returns the provider dict, or an error response tuple (404)."""
        p = _load(rag_id)
        if p is None:
            _audit_fail(404, "not_found", rag_id=rag_id)
            return _err(404, "unknown_rag_id", f"rag_id '{rag_id}' not in registry")
        return p

    # ----------------------------------------------------------- /health

    @app.get("/health")
    def health():
        with rdb.session(cfg.db_path) as conn:
            n = conn.execute("SELECT COUNT(*) c FROM rag_providers").fetchone()["c"]
            na = conn.execute(
                "SELECT COUNT(*) c FROM rag_providers WHERE enabled = 1 AND archived = 0"
            ).fetchone()["c"]
        return _ok({"service": "rag-registry", "version": "e1",
                    "providers": n, "enabled": na})

    # -------------------------------------------------------------- /metrics

    @app.get("/metrics")
    def metrics():
        """Prometheus text exposition (scraped on localhost, no auth).

        Additive observability (post-E1): never exposes auth_ref / key
        material, only counters and registry state.
        """
        with rdb.session(cfg.db_path) as conn:
            n = conn.execute(
                "SELECT COUNT(*) c FROM rag_providers").fetchone()["c"]
            n_enabled = conn.execute(
                "SELECT COUNT(*) c FROM rag_providers "
                "WHERE enabled = 1 AND archived = 0").fetchone()["c"]
            n_cons = conn.execute(
                "SELECT COUNT(*) c FROM rag_consumers WHERE enabled = 1"
            ).fetchone()["c"]
            audit_rows = conn.execute(
                "SELECT action, COUNT(*) c FROM rag_registry_audit "
                "GROUP BY action").fetchall()
        by_action = {r["action"]: r["c"] for r in audit_rows}
        lines = [
            "# HELP rag_up Service liveness",
            "# TYPE rag_up gauge",
            "rag_up 1",
            "# HELP rag_providers_total Registered RAG providers (incl. archived)",
            "# TYPE rag_providers_total gauge",
            "rag_providers_total %d" % n,
            "# HELP rag_providers_enabled_enabled Active (enabled, non-archived) providers",
            "# TYPE rag_providers_enabled_enabled gauge",
            "rag_providers_enabled_enabled %d" % n_enabled,
            "# HELP rag_consumers_enabled_enabled Active consumers",
            "# TYPE rag_consumers_enabled_enabled gauge",
            "rag_consumers_enabled_enabled %d" % n_cons,
            "# HELP rag_audit_entries_total Audit trail entries by action (lifetime)",
            "# TYPE rag_audit_entries_total counter",
        ]
        for action in sorted(by_action):
            lines.append('rag_audit_entries_total{action="%s"} %d'
                         % (action.replace('"', ""), by_action[action]))
        if not by_action:
            lines.append("rag_audit_entries_total 0")
        return "\n".join(lines) + "\n", 200, {"Content-Type": "text/plain; version=0.0.4"}

    # ------------------------------------------------- provider collection

    @app.get("/api/rag-registry")
    @_auth
    def list_providers():
        include_archived = request.args.get("archived", "false") == "true"
        only_enabled = request.args.get("enabled", "false") == "true"
        with rdb.session(cfg.db_path) as conn:
            q = "SELECT * FROM rag_providers WHERE 1=1"
            if not include_archived:
                q += " AND archived = 0"
            if only_enabled:
                q += " AND enabled = 1"
            q += " ORDER BY priority ASC, rag_id ASC"
            rows = conn.execute(q).fetchall()
        return _ok({"providers": [rdb.provider_to_dict(r) for r in rows]})

    @app.post("/api/rag-registry")
    @_auth
    @_require("write")
    def create_provider():
        data = request.get_json(force=True, silent=True) or {}
        missing = [f for f in REQUIRED_FIELDS if data.get(f) in (None, "")]
        if missing:
            return _err(400, "validation_error",
                        f"missing required fields: {', '.join(missing)}")
        rag_id = str(data["rag_id"]).strip()
        if not _RAG_ID_RE.match(rag_id):
            return _err(400, "validation_error",
                        "rag_id must match ^[a-z0-9][a-z0-9._-]{0,63}$")
        try:
            validate_auth_ref(str(data.get("auth_ref") or ""))
            ssrf.validate(str(data["base_url"]).strip())
        except (SecretError, SSRFError) as e:
            return _err(400, getattr(e, "code", "validation_error"),
                        getattr(e, "detail", str(e)))

        ts = rdb.now_iso()
        values = {
            "rag_id": rag_id,
            "rag_name": str(data.get("rag_name") or rag_id),
            "display_name": str(data["display_name"]).strip(),
            "description": str(data.get("description") or ""),
            "provider_type": str(data["provider_type"]).strip(),
            "base_url": str(data["base_url"]).strip(),
            "api_endpoint": str(data.get("api_endpoint") or "/v1").strip(),
            "api_contract_version": str(data["api_contract_version"]).strip(),
            "healthcheck_endpoint": str(data.get("healthcheck_endpoint") or "/health").strip(),
            "auth_ref": str(data.get("auth_ref") or ""),
            "master_prompt_id": str(data.get("master_prompt_id") or ""),
            "priority": int(data["priority"]),
            "retrieval_weight": float(data.get("retrieval_weight", 1.0)),
            "fallback_priority": int(data.get("fallback_priority", 100)),
            "retrieval_config": json.dumps(data.get("retrieval_config") or {},
                                           ensure_ascii=False, separators=(",", ":")),
            "embedding_model": str(data["embedding_model"]).strip(),
            "vector_index": str(data.get("vector_index") or ""),
            "top_k": int(data.get("top_k", 5)),
            "similarity_threshold": float(data.get("similarity_threshold", 0.05)),
            "timeout_ms": int(data.get("timeout_ms", 10000)),
            "retry_policy": json.dumps(data.get("retry_policy") or
                                       {"max_retries": 1, "backoff_ms": 500},
                                       separators=(",", ":")),
            "enabled": 1 if data.get("enabled", True) else 0,
            "allowed_consumers": json.dumps(data.get("allowed_consumers") or [],
                                            ensure_ascii=False, separators=(",", ":")),
            "allowed_users": json.dumps(data.get("allowed_users") or [],
                                        ensure_ascii=False, separators=(",", ":")),
            "created_at": ts,
            "updated_at": ts,
            "created_by": _actor(),
        }
        cols = ", ".join(values)
        ph = ", ".join("?" * len(values))
        try:
            with rdb.session(cfg.db_path) as conn:
                conn.execute(f"INSERT INTO rag_providers ({cols}) VALUES ({ph})",
                             list(values.values()))
        except Exception:
            return _err(409, "rag_id_exists", f"rag_id '{rag_id}' already exists")

        if (data.get("master_prompt") or "").strip():
            with rdb.session(cfg.db_path) as conn:
                pid = f"mp-{rag_id}-v1"
                conn.execute(
                    "INSERT INTO rag_master_prompts (prompt_id, rag_id, version, body, "
                    "status, created_by, created_at, audit_ref) "
                    "VALUES (?,?,?,?,?,?,?,?)",
                    (pid, rag_id, 1, str(data["master_prompt"]).strip(), "active",
                     _actor(), ts, ""))
                conn.execute("UPDATE rag_providers SET master_prompt_id = ? "
                             "WHERE rag_id = ?", (pid, rag_id))
            values["master_prompt_id"] = pid

        _audit("create", rag_id,
               {"fields": sorted(values.keys()),
                "priority": values["priority"],
                "retrieval_weight": values["retrieval_weight"],
                "fallback_priority": values["fallback_priority"],
                "enabled": bool(values["enabled"])})
        return _ok({"provider": _load(rag_id)}, 201)

    # ------------------------------------------------------ single provider

    @app.get("/api/rag-registry/<rag_id>")
    @_auth
    def get_provider(rag_id: str):
        p = _get_provider(rag_id)
        if isinstance(p, tuple):
            return p
        return _ok({"provider": p})

    @app.patch("/api/rag-registry/<rag_id>")
    @_auth
    @_require("write")
    def patch_provider(rag_id: str):
        data = request.get_json(force=True, silent=True) or {}
        ifm = request.headers.get("If-Match")
        if not ifm:
            return _err(428, "if_match_required",
                        "PATCH requires If-Match header with the current updated_at")
        p = _load(rag_id)
        if p is None:
            _audit_fail(404, "not_found", rag_id=rag_id)
            return _err(404, "unknown_rag_id", f"rag_id '{rag_id}' not in registry")
        if ifm.strip('"') != p["updated_at"]:
            _audit_fail(409, "conflict", rag_id=rag_id,
                        detail="stale updated_at (optimistic concurrency)")
            return _err(409, "conflict",
                        "stale update: If-Match does not match current updated_at")

        changes = {f: data[f] for f in PATCHABLE_FIELDS
                   if f in data and data[f] is not None}
        if not changes:
            return _err(400, "validation_error", "no patchable fields provided")
        try:
            if "auth_ref" in changes:
                validate_auth_ref(str(changes["auth_ref"]))
            if "base_url" in changes:
                ssrf.validate(str(changes["base_url"]).strip())
            for f in ("priority", "fallback_priority", "top_k", "timeout_ms"):
                if f in changes:
                    changes[f] = int(changes[f])
            for f in ("retrieval_weight", "similarity_threshold"):
                if f in changes:
                    changes[f] = float(changes[f])
            for f in ("retrieval_config", "retry_policy", "allowed_consumers",
                      "allowed_users"):
                if f in changes:
                    changes[f] = json.dumps(changes[f], ensure_ascii=False,
                                            separators=(",", ":"))
        except (SecretError, SSRFError) as e:
            return _err(400, getattr(e, "code", "validation_error"),
                        getattr(e, "detail", str(e)))
        except (ValueError, TypeError) as e:
            return _err(400, "validation_error", str(e))

        ts = rdb.now_iso()
        sets = ", ".join(f"{f} = ?" for f in changes)
        with rdb.session(cfg.db_path) as conn:
            cur = conn.execute(
                f"UPDATE rag_providers SET {sets}, updated_at = ? "
                "WHERE rag_id = ? AND updated_at = ?",
                [*changes.values(), ts, rag_id, p["updated_at"]])
        if cur.rowcount == 0:
            _audit_fail(409, "conflict", rag_id=rag_id)
            return _err(409, "conflict", "stale update (If-Match mismatch)")
        _audit("update", rag_id, changes)
        return _ok({"provider": _load(rag_id)})

    # -------------------------------------------------------- enable/disable

    @app.post("/api/rag-registry/<rag_id>/enable")
    @_auth
    @_require("enable")
    def enable_provider(rag_id: str):
        with rdb.session(cfg.db_path) as conn:
            cur = conn.execute(
                "UPDATE rag_providers SET enabled = 1, updated_at = ? "
                "WHERE rag_id = ?", (rdb.now_iso(), rag_id))
        if cur.rowcount == 0:
            _audit_fail(404, "not_found", rag_id=rag_id)
            return _err(404, "unknown_rag_id", f"rag_id '{rag_id}' not in registry")
        _audit("enable", rag_id, {"enabled": True})
        return _ok({"provider": _load(rag_id)})

    @app.post("/api/rag-registry/<rag_id>/disable")
    @_auth
    @_require("disable")
    def disable_provider(rag_id: str):
        with rdb.session(cfg.db_path) as conn:
            cur = conn.execute(
                "UPDATE rag_providers SET enabled = 0, updated_at = ? "
                "WHERE rag_id = ?", (rdb.now_iso(), rag_id))
        if cur.rowcount == 0:
            _audit_fail(404, "not_found", rag_id=rag_id)
            return _err(404, "unknown_rag_id", f"rag_id '{rag_id}' not in registry")
        _audit("disable", rag_id, {"enabled": False})
        return _ok({"provider": _load(rag_id)})

    @app.post("/api/rag-registry/<rag_id>/archive")
    @_auth
    @_require("write")
    def archive_provider(rag_id: str):
        with rdb.session(cfg.db_path) as conn:
            cur = conn.execute(
                "UPDATE rag_providers SET archived = 1, enabled = 0, updated_at = ? "
                "WHERE rag_id = ?", (rdb.now_iso(), rag_id))
        if cur.rowcount == 0:
            _audit_fail(404, "not_found", rag_id=rag_id)
            return _err(404, "unknown_rag_id", f"rag_id '{rag_id}' not in registry")
        _audit("archive", rag_id, {"archived": True, "enabled": False})
        return _ok({"provider": _load(rag_id)})

    # --------------------------------------------------------------- probes

    @app.post("/api/rag-registry/<rag_id>/test-connection")
    @_auth
    @_require("test")
    def test_connection(rag_id: str):
        p = _get_provider(rag_id)
        if isinstance(p, tuple):
            return p
        res = pc.probe_connection(ssrf, p["base_url"],
                                  p["healthcheck_endpoint"] or "/health",
                                  p["timeout_ms"])
        _audit("test_connection", rag_id, {"ok": res.ok, "status": res.status})
        return _ok({"result": res.to_dict()}) if res.ok else \
            (jsonify({"ok": False, "result": res.to_dict()}), 200)

    @app.post("/api/rag-registry/<rag_id>/test-auth")
    @_auth
    @_require("test")
    def test_auth(rag_id: str):
        p = _get_provider(rag_id)
        if isinstance(p, tuple):
            return p
        res = pc.probe_auth(ssrf, p["base_url"], p["auth_ref"], p["timeout_ms"])
        _audit("test_auth", rag_id, {"ok": res.ok, "status": res.status,
                                     "auth_ref": p["auth_ref"]})
        return (jsonify({"ok": res.ok, "result": res.to_dict()}), 200)

    @app.post("/api/rag-registry/<rag_id>/test-retrieval")
    @_auth
    @_require("test")
    def test_retrieval(rag_id: str):
        p = _get_provider(rag_id)
        if isinstance(p, tuple):
            return p
        data = request.get_json(force=True, silent=True) or {}
        query = str(data.get("query") or "تفسیر")
        collection = data.get("collection_id") or data.get("collection")
        res = pc.probe_retrieval(ssrf, p["base_url"], p["auth_ref"],
                                 query=query, collection=collection,
                                 timeout_ms=p["timeout_ms"])
        _audit("test_retrieval", rag_id,
               {"ok": res.ok, "status": res.status,
                "collection": collection or "auto"})
        return (jsonify({"ok": res.ok, "result": res.to_dict()}), 200)

    @app.get("/api/rag-registry/<rag_id>/health")
    @_auth
    def get_health(rag_id: str):
        p = _get_provider(rag_id)
        if isinstance(p, tuple):
            return p
        res = pc.probe_connection(ssrf, p["base_url"],
                                  p["healthcheck_endpoint"] or "/health",
                                  p["timeout_ms"])
        with rdb.session(cfg.db_path) as conn:
            last = conn.execute(
                "SELECT action, at, diff_json FROM rag_registry_audit "
                "WHERE rag_id = ? AND action LIKE 'test%' ORDER BY id DESC LIMIT 1",
                (rag_id,)).fetchone()
        last_test = None
        if last:
            try:
                last_test = {"action": last["action"], "at": last["at"],
                             **json.loads(last["diff_json"] or "{}")}
            except json.JSONDecodeError:
                last_test = {"action": last["action"], "at": last["at"]}
        return _ok({"provider": p["rag_id"], "connection": res.to_dict(),
                    "last_test": last_test})

    # ------------------------------------------------------------- prompts

    @app.get("/api/rag-registry/<rag_id>/prompts")
    @_auth
    def list_prompts(rag_id: str):
        p = _get_provider(rag_id)
        if isinstance(p, tuple):
            return p
        with rdb.session(cfg.db_path) as conn:
            rows = conn.execute(
                "SELECT * FROM rag_master_prompts WHERE rag_id = ? "
                "ORDER BY version DESC", (rag_id,)).fetchall()
        return _ok({"rag_id": rag_id,
                    "prompts": [rdb.prompt_to_dict(r) for r in rows]})

    @app.post("/api/rag-registry/<rag_id>/prompts")
    @_auth
    @_require("write")
    def create_prompt(rag_id: str):
        p = _get_provider(rag_id)
        if isinstance(p, tuple):
            return p
        data = request.get_json(force=True, silent=True) or {}
        body = str(data.get("body") or "").strip()
        if not body:
            return _err(400, "validation_error", "prompt body is required")
        status = str(data.get("status") or "draft")
        if status not in ("draft", "active"):
            return _err(400, "validation_error",
                        "new prompt status must be 'draft' or 'active'")
        with rdb.session(cfg.db_path) as conn:
            version = rdb.next_prompt_version(conn, rag_id)
            pid = f"mp-{rag_id}-v{version}"
            if status == "active":
                prev = conn.execute(
                    "SELECT version FROM rag_master_prompts "
                    "WHERE rag_id = ? AND status = 'active'", (rag_id,)).fetchone()
                conn.execute(
                    "UPDATE rag_master_prompts SET status = 'archived' "
                    "WHERE rag_id = ? AND status = 'active'", (rag_id,))
                conn.execute("UPDATE rag_providers SET master_prompt_id = ?, "
                             "updated_at = ? WHERE rag_id = ?",
                             (pid, rdb.now_iso(), rag_id))
                rdb.audit(conn, "prompt_activate", rag_id=rag_id, actor=_actor(),
                          diff={"version": version,
                                "replaced": (prev["version"] if prev else None),
                                "via": "create"})
            audit_ref = str(rdb.audit(conn, "prompt_create", rag_id=rag_id,
                                      actor=_actor(),
                                      diff={"version": version, "status": status,
                                            "body_len": len(body)}))
            conn.execute(
                "INSERT INTO rag_master_prompts (prompt_id, rag_id, version, body, "
                "status, created_by, created_at, audit_ref) VALUES (?,?,?,?,?,?,?,?)",
                (pid, rag_id, version, body, status, _actor(), rdb.now_iso(),
                 str(audit_ref)))
        return _ok({"prompt_id": pid, "rag_id": rag_id,
                    "version": version, "status": status}, 201)

    @app.post("/api/rag-registry/<rag_id>/prompts/<int:version>/activate")
    @_auth
    @_require("write")
    def activate_prompt(rag_id: str, version: int):
        p = _get_provider(rag_id)
        if isinstance(p, tuple):
            return p
        with rdb.session(cfg.db_path) as conn:
            row = conn.execute(
                "SELECT * FROM rag_master_prompts WHERE rag_id = ? AND version = ?",
                (rag_id, version)).fetchone()
            if row is None:
                _audit_fail(404, "not_found", rag_id=rag_id,
                            detail=f"prompt v{version} missing")
                return _err(404, "unknown_prompt_version",
                            f"version {version} not found for {rag_id}")
            prev = conn.execute(
                "SELECT prompt_id, version FROM rag_master_prompts "
                "WHERE rag_id = ? AND status = 'active'", (rag_id,)).fetchone()
            conn.execute(
                "UPDATE rag_master_prompts SET status = 'archived' "
                "WHERE rag_id = ? AND status = 'active'", (rag_id,))
            conn.execute(
                "UPDATE rag_master_prompts SET status = 'active' "
                "WHERE rag_id = ? AND version = ?", (rag_id, version))
            conn.execute("UPDATE rag_providers SET master_prompt_id = ?, "
                         "updated_at = ? WHERE rag_id = ?",
                         (row["prompt_id"], rdb.now_iso(), rag_id))
            audit_ref = str(rdb.audit(conn, "prompt_activate", rag_id=rag_id,
                                      actor=_actor(),
                                      diff={"version": version,
                                            "replaced": (prev["version"] if prev else None)}))
        return _ok({"rag_id": rag_id, "version": version,
                    "status": "active", "audit_ref": audit_ref})

    # ----------------------------------------------------------- priorities

    @app.post("/api/rag-registry/<rag_id>/priority")
    @_auth
    @_require("write")
    def set_priority(rag_id: str):
        data = request.get_json(force=True, silent=True) or {}
        p = _load(rag_id)
        if p is None:
            _audit_fail(404, "not_found", rag_id=rag_id)
            return _err(404, "unknown_rag_id", f"rag_id '{rag_id}' not in registry")
        changes: dict = {}
        for f in ("priority", "fallback_priority"):
            if f in data and data[f] is not None:
                try:
                    changes[f] = int(data[f])
                except (ValueError, TypeError):
                    return _err(400, "validation_error", f"{f} must be an integer")
        if "retrieval_weight" in data and data["retrieval_weight"] is not None:
            try:
                changes["retrieval_weight"] = float(data["retrieval_weight"])
            except (ValueError, TypeError):
                return _err(400, "validation_error",
                            "retrieval_weight must be a number")
            if changes["retrieval_weight"] < 0:
                return _err(400, "validation_error",
                            "retrieval_weight must be >= 0")
        if not changes:
            return _err(400, "validation_error",
                        "provide priority, fallback_priority and/or retrieval_weight")
        ifm = request.headers.get("If-Match")
        ts = rdb.now_iso()
        sets = ", ".join(f"{f} = ?" for f in changes)
        with rdb.session(cfg.db_path) as conn:
            if ifm:
                cur = conn.execute(
                    f"UPDATE rag_providers SET {sets}, updated_at = ? "
                    "WHERE rag_id = ? AND updated_at = ?",
                    [*changes.values(), ts, rag_id, ifm.strip('"')])
            else:
                cur = conn.execute(
                    f"UPDATE rag_providers SET {sets}, updated_at = ? "
                    "WHERE rag_id = ?", [*changes.values(), ts, rag_id])
        if cur.rowcount == 0 and ifm:
            _audit_fail(409, "conflict", rag_id=rag_id)
            return _err(409, "conflict", "stale update (If-Match mismatch)")
        _audit("set_priority", rag_id, changes)
        return _ok({"provider": _load(rag_id)})

    # ------------------------------------------------------------- consumers

    @app.get("/api/rag-registry/consumers")
    @_auth
    def list_consumers():
        with rdb.session(cfg.db_path) as conn:
            rows = conn.execute(
                "SELECT * FROM rag_consumers WHERE enabled = 1 ORDER BY consumer_id"
            ).fetchall()
        return _ok({"consumers": [rdb.consumer_to_dict(r) for r in rows]})

    @app.post("/api/rag-registry/consumers")
    @_auth
    @_require("manage_consumers")
    def create_consumer():
        data = request.get_json(force=True, silent=True) or {}
        consumer_id = str(data.get("consumer_id") or "").strip()
        if not _CONSUMER_ID_RE.match(consumer_id):
            return _err(400, "validation_error",
                        "consumer_id must match ^[a-z0-9][a-z0-9._-]{0,63}$")
        policy = str(data.get("routing_policy") or "priority")
        if policy not in _ROUTING_POLICIES:
            return _err(400, "validation_error",
                        "routing_policy must be single|priority|fusion")
        try:
            timeout_ms = int(data.get("timeout_ms", 60000))
        except (ValueError, TypeError):
            return _err(400, "validation_error", "timeout_ms must be an integer")
        raw_key = str(data.get("api_key") or _pysecrets.token_urlsafe(32))
        key_hash = hashlib.sha256(raw_key.encode("utf-8")).hexdigest()
        ts = rdb.now_iso()
        allowed = json.dumps(data.get("allowed_rag_ids") or [],
                             ensure_ascii=False, separators=(",", ":"))
        try:
            with rdb.session(cfg.db_path) as conn:
                conn.execute(
                    "INSERT INTO rag_consumers (consumer_id, display_name, description, "
                    "key_hash, allowed_rag_ids, default_rag_id, routing_policy, "
                    "timeout_ms, stream_allowed, citation_format, enabled, "
                    "created_at, updated_at, created_by) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (consumer_id, str(data.get("display_name") or consumer_id),
                     str(data.get("description") or ""), key_hash, allowed,
                     str(data.get("default_rag_id") or ""), policy, timeout_ms,
                     1 if data.get("stream_allowed", True) else 0,
                     str(data.get("citation_format") or "standard"), 1,
                     ts, ts, _actor()))
        except Exception:
            return _err(409, "consumer_exists",
                        f"consumer_id '{consumer_id}' already exists")
        _audit("consumer_create", None,
               {"consumer_id": consumer_id, "routing_policy": policy,
                "default_rag_id": str(data.get("default_rag_id") or "")})
        with rdb.session(cfg.db_path) as conn:
            row = conn.execute(
                "SELECT * FROM rag_consumers WHERE consumer_id = ?",
                (consumer_id,)).fetchone()
        return _ok({"consumer": rdb.consumer_to_dict(row), "api_key": raw_key,
                    "key_notice": "store now; the key is shown exactly once"}, 201)

    @app.patch("/api/rag-registry/consumers/<consumer_id>")
    @_auth
    @_require("manage_consumers")
    def patch_consumer(consumer_id: str):
        data = request.get_json(force=True, silent=True) or {}
        ifm = request.headers.get("If-Match")
        with rdb.session(cfg.db_path) as conn:
            row = conn.execute(
                "SELECT * FROM rag_consumers WHERE consumer_id = ?",
                (consumer_id,)).fetchone()
            if row is None:
                _audit_fail(404, "not_found", detail=f"consumer '{consumer_id}'")
                return _err(404, "unknown_consumer",
                            f"consumer '{consumer_id}' not found")
            if ifm and ifm.strip('"') != row["updated_at"]:
                _audit_fail(409, "conflict", detail="consumer stale")
                return _err(409, "conflict", "stale consumer update")
            changes: dict = {}
            for f in ("display_name", "description", "default_rag_id",
                      "routing_policy", "citation_format"):
                if f in data and data[f] is not None:
                    if f == "routing_policy" and str(data[f]) not in _ROUTING_POLICIES:
                        return _err(400, "validation_error",
                                    "routing_policy must be single|priority|fusion")
                    changes[f] = str(data[f])
            if "timeout_ms" in data and data["timeout_ms"] is not None:
                try:
                    changes["timeout_ms"] = int(data["timeout_ms"])
                except (ValueError, TypeError):
                    return _err(400, "validation_error",
                                "timeout_ms must be an integer")
            if "allowed_rag_ids" in data and data["allowed_rag_ids"] is not None:
                changes["allowed_rag_ids"] = json.dumps(
                    data["allowed_rag_ids"], ensure_ascii=False, separators=(",", ":"))
            if "stream_allowed" in data and data["stream_allowed"] is not None:
                changes["stream_allowed"] = 1 if data["stream_allowed"] else 0
            if "enabled" in data and data["enabled"] is not None:
                changes["enabled"] = 1 if data["enabled"] else 0
            if not changes:
                return _err(400, "validation_error", "no patchable fields")
            ts = rdb.now_iso()
            sets = ", ".join(f"{f} = ?" for f in changes)
            conn.execute(
                f"UPDATE rag_consumers SET {sets}, updated_at = ? "
                "WHERE consumer_id = ?", [*changes.values(), ts, consumer_id])
        _audit("consumer_update", None, {"consumer_id": consumer_id, **changes})
        with rdb.session(cfg.db_path) as conn:
            row = conn.execute(
                "SELECT * FROM rag_consumers WHERE consumer_id = ?",
                (consumer_id,)).fetchone()
        return _ok({"consumer": rdb.consumer_to_dict(row)})

    @app.post("/api/rag-registry/consumers/verify")
    @_auth
    def verify_consumer_key():
        """Gateway inbound auth (E2): validate a consumer key sent in body.

        The gateway calls this with its own registry token (read role) plus
        the consumer key from the inbound request. Only the consumer record
        is returned — no key material, ever.
        """
        data = request.get_json(force=True, silent=True) or {}
        key = str(data.get("key") or "")
        if not key:
            _audit_fail(400, "validation_error", detail="verify without key")
            return _err(400, "validation_error", "key is required")
        kh = hashlib.sha256(key.encode("utf-8")).hexdigest()
        with rdb.session(cfg.db_path) as conn:
            row = conn.execute(
                "SELECT * FROM rag_consumers WHERE key_hash = ?", (kh,)
            ).fetchone()
        if row is None:
            _audit_fail(401, "unknown_key", detail="verify: key not recognized")
            return _err(401, "unknown_key", "consumer key not recognized")
        if not row["enabled"]:
            _audit_fail(403, "consumer_disabled",
                        detail=f"consumer '{row['consumer_id']}' disabled")
            return _err(403, "consumer_disabled",
                        f"consumer '{row['consumer_id']}' is disabled")
        _audit("consumer_verify", None,
               {"consumer_id": row["consumer_id"], "ok": True})
        return _ok({"consumer": rdb.consumer_to_dict(row)})

    @app.post("/api/rag-registry/consumers/<consumer_id>/rotate-key")
    @_auth
    @_require("manage_consumers")
    def rotate_consumer_key(consumer_id: str):
        """Rotate a consumer key. The old key stops working immediately;
        the new key is returned exactly once (never stored in plaintext)."""
        with rdb.session(cfg.db_path) as conn:
            row = conn.execute(
                "SELECT * FROM rag_consumers WHERE consumer_id = ?",
                (consumer_id,)).fetchone()
            if row is None:
                _audit_fail(404, "not_found", detail=f"consumer '{consumer_id}'")
                return _err(404, "unknown_consumer",
                            f"consumer '{consumer_id}' not found")
            raw_key = f"{cfg.consumer_key_prefix}{_pysecrets.token_urlsafe(32)}"
            kh = hashlib.sha256(raw_key.encode("utf-8")).hexdigest()
            ts = rdb.now_iso()
            conn.execute(
                "UPDATE rag_consumers SET key_hash = ?, updated_at = ? "
                "WHERE consumer_id = ?", (kh, ts, consumer_id))
        _audit("consumer_key_rotate", None, {"consumer_id": consumer_id})
        with rdb.session(cfg.db_path) as conn:
            row = conn.execute(
                "SELECT * FROM rag_consumers WHERE consumer_id = ?",
                (consumer_id,)).fetchone()
        return _ok({"consumer": rdb.consumer_to_dict(row), "api_key": raw_key,
                    "key_notice": ("previous key is invalid immediately; "
                                   "store now — shown exactly once")})

    @app.get("/api/rag-registry/consumers/<consumer_id>/rags")
    @_auth
    def consumer_rags(consumer_id: str):
        """Consumer-scoped source list (E0 §6 UI integration / E5-prep).

        Returns the enabled, non-archived providers this consumer may use —
        the exact dual filter the gateway enforces at request time
        (``MULTI_RAG_CONSUMER_ARCHITECTURE.md`` §3.2): the consumer's
        ``allowed_rag_ids`` AND each provider's ``allowed_consumers`` (an
        empty provider list means all consumers). Feeds the E5 Source Picker
        and Settings → RAG Management UI. Read-only; viewer is enough.
        """
        with rdb.session(cfg.db_path) as conn:
            crow = conn.execute(
                "SELECT * FROM rag_consumers WHERE consumer_id = ?",
                (consumer_id,)).fetchone()
            if crow is None:
                _audit_fail(404, "not_found", detail=f"consumer '{consumer_id}'")
                return _err(404, "unknown_consumer",
                            f"consumer '{consumer_id}' not found")
            consumer = rdb.consumer_to_dict(crow)
            rows = conn.execute(
                "SELECT * FROM rag_providers WHERE enabled = 1 AND archived = 0"
            ).fetchall()
        providers = [rdb.provider_to_dict(r) for r in rows]
        allowed = consumer.get("allowed_rag_ids") or []
        if allowed:
            providers = [p for p in providers if p["rag_id"] in allowed]
        providers = [p for p in providers
                     if not p.get("allowed_consumers")
                     or consumer_id in p["allowed_consumers"]]
        providers.sort(key=lambda p: (p["priority"], p["rag_id"]))
        return _ok({"consumer": consumer, "providers": providers,
                    "model_aliases": {
                        "single": [f"rag-{p['rag_id']}" for p in providers],
                        "multi": "rag-general"},
                    "sources_for_general": [p["rag_id"] for p in providers]})

    # ------------------------------------------------------------- version

    @app.get("/api/rag-registry/version")
    @_auth
    def registry_version():
        """Cache-invalidation token for the gateway (E0 §6, 15s cache).

        version = max(updated_at) across providers and consumers; the
        gateway re-fetches the registry when this changes.
        """
        with rdb.session(cfg.db_path) as conn:
            prov = conn.execute(
                "SELECT MAX(updated_at) AS m FROM rag_providers").fetchone()["m"]
            cons = conn.execute(
                "SELECT MAX(updated_at) AS m FROM rag_consumers").fetchone()["m"]
            n_enabled = conn.execute(
                "SELECT COUNT(*) AS c FROM rag_providers WHERE enabled = 1"
            ).fetchone()["c"]
        return _ok({"version": max(prov or "", cons or ""),
                    "providers_enabled": n_enabled})

    # ---------------------------------------------------------------- audit

    @app.get("/api/rag-registry/audit")
    @_auth
    def list_audit():
        rag_id = request.args.get("rag_id")
        try:
            limit = min(int(request.args.get("limit", 100) or 100), 500)
            offset = max(int(request.args.get("offset", 0) or 0), 0)
        except ValueError:
            return _err(400, "validation_error", "limit/offset must be integers")
        with rdb.session(cfg.db_path) as conn:
            if rag_id:
                rows = conn.execute(
                    "SELECT * FROM rag_registry_audit WHERE rag_id = ? "
                    "ORDER BY id DESC LIMIT ? OFFSET ?", (rag_id, limit, offset)
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM rag_registry_audit ORDER BY id DESC LIMIT ? OFFSET ?",
                    (limit, offset)).fetchall()
        return _ok({"audit": [rdb.audit_to_dict(r) for r in rows]})

    @app.get("/api/rag-registry/errors")
    @_auth
    def errors_endpoint():
        """Aggregate recent probe failures (UI 'errors' card)."""
        with rdb.session(cfg.db_path) as conn:
            rows = conn.execute(
                "SELECT rag_id, action, at, diff_json FROM rag_registry_audit "
                "WHERE action LIKE 'test%' AND diff_json LIKE '%\"ok\":false' "
                "ORDER BY id DESC LIMIT 50").fetchall()
        out = []
        for r in rows:
            try:
                d = json.loads(r["diff_json"] or "{}")
            except json.JSONDecodeError:
                d = {}
            out.append({"rag_id": r["rag_id"], "action": r["action"],
                        "at": r["at"], "status": d.get("status")})
        return _ok({"errors": out})

    @app.errorhandler(404)
    def _nf(e):
        return _err(404, "not_found", "route not found")

    @app.errorhandler(405)
    def _nm(e):
        return _err(405, "method_not_allowed", "method not allowed")

    @app.errorhandler(500)
    def _e500(e):
        return _err(500, "internal_error", "unexpected server error")

    return app
