"""SQLite schema + connection helpers for the central RAG registry (E1).

Strictly additive (``CREATE TABLE IF NOT EXISTS``) and follows the frozen E0
data model in ``docs/architecture/RAG_REGISTRY_AND_CONFIGURATION.md`` §1:

- ``rag_providers``      — one row per registered RAG provider
- ``rag_master_prompts`` — versioned master prompts (one ``active`` per RAG)
- ``rag_registry_audit`` — append-only audit trail

plus the consumer table from
``docs/architecture/MULTI_RAG_CONSUMER_ARCHITECTURE.md`` §4:

- ``rag_consumers``      — per-consumer (virtual key) settings; the key is
  stored only as a SHA-256 hash, never in plaintext.
"""
from __future__ import annotations

import json
import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Iterator

PROVIDER_TYPES = (
    "native", "openai_compat", "mizan", "fiqh", "tasnim", "radio", "gateway",
)
PROMPT_STATUSES = ("draft", "active", "archived")
ROUTING_POLICIES = ("single", "priority", "fusion")

_JSON_FIELDS_PROVIDER = ("retrieval_config", "retry_policy", "allowed_consumers", "allowed_users")

SCHEMA = """
CREATE TABLE IF NOT EXISTS rag_providers (
    rag_id TEXT PRIMARY KEY,
    rag_name TEXT NOT NULL,
    display_name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    provider_type TEXT NOT NULL,
    base_url TEXT NOT NULL,
    api_endpoint TEXT NOT NULL DEFAULT '/v1',
    api_contract_version TEXT NOT NULL DEFAULT 'v1',
    healthcheck_endpoint TEXT NOT NULL DEFAULT '/health',
    auth_ref TEXT NOT NULL DEFAULT '',
    master_prompt_id TEXT NOT NULL DEFAULT '',
    priority INTEGER NOT NULL DEFAULT 100,
    retrieval_weight REAL NOT NULL DEFAULT 1.0,
    fallback_priority INTEGER NOT NULL DEFAULT 100,
    retrieval_config TEXT NOT NULL DEFAULT '{}',
    embedding_model TEXT NOT NULL,
    vector_index TEXT NOT NULL DEFAULT '',
    top_k INTEGER NOT NULL DEFAULT 5,
    similarity_threshold REAL NOT NULL DEFAULT 0.05,
    timeout_ms INTEGER NOT NULL DEFAULT 10000,
    retry_policy TEXT NOT NULL DEFAULT '{"max_retries": 1, "backoff_ms": 500}',
    enabled INTEGER NOT NULL DEFAULT 1,
    archived INTEGER NOT NULL DEFAULT 0,
    allowed_consumers TEXT NOT NULL DEFAULT '[]',
    allowed_users TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    created_by TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS rag_master_prompts (
    prompt_id TEXT PRIMARY KEY,
    rag_id TEXT NOT NULL REFERENCES rag_providers(rag_id),
    version INTEGER NOT NULL,
    body TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'draft',
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL,
    audit_ref TEXT NOT NULL DEFAULT '',
    UNIQUE (rag_id, version)
);

CREATE TABLE IF NOT EXISTS rag_registry_audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    rag_id TEXT,
    action TEXT NOT NULL,
    actor TEXT NOT NULL,
    diff_json TEXT NOT NULL DEFAULT '',
    at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS rag_consumers (
    consumer_id TEXT PRIMARY KEY,
    display_name TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    key_hash TEXT NOT NULL UNIQUE,
    allowed_rag_ids TEXT NOT NULL DEFAULT '[]',
    default_rag_id TEXT NOT NULL DEFAULT '',
    routing_policy TEXT NOT NULL DEFAULT 'priority',
    timeout_ms INTEGER NOT NULL DEFAULT 60000,
    stream_allowed INTEGER NOT NULL DEFAULT 1,
    citation_format TEXT NOT NULL DEFAULT 'standard',
    enabled INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    created_by TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_prompts_rag ON rag_master_prompts (rag_id, version);
CREATE INDEX IF NOT EXISTS idx_audit_rag ON rag_registry_audit (rag_id, id);
"""


def now_iso() -> str:
    """UTC timestamp with millisecond precision (stable, sortable)."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


def connect(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA synchronous=NORMAL")
    return conn


def init_db(db_path: str) -> None:
    parent = os.path.dirname(db_path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    conn = connect(db_path)
    try:
        conn.executescript(SCHEMA)
        conn.commit()
    finally:
        conn.close()


@contextmanager
def session(db_path: str) -> Iterator[sqlite3.Connection]:
    conn = connect(db_path)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def audit(conn: sqlite3.Connection, action: str, *, rag_id: str | None = None,
          actor: str, diff: dict[str, Any] | None = None) -> int:
    """Append one audit row (never modified afterwards). Returns the id."""
    cur = conn.execute(
        "INSERT INTO rag_registry_audit (rag_id, action, actor, diff_json, at) "
        "VALUES (?, ?, ?, ?, ?)",
        (rag_id, action, actor or "anonymous",
         json.dumps(diff or {}, ensure_ascii=False, separators=(",", ":")),
         now_iso()),
    )
    return int(cur.lastrowid or 0)


# ---------------------------------------------------------------- rows


def provider_to_dict(row: sqlite3.Row) -> dict[str, Any]:
    d = dict(row)
    for field in _JSON_FIELDS_PROVIDER:
        raw = d.get(field) or ""
        try:
            d[field] = json.loads(raw) if raw else ([] if field.startswith("allowed_") else {})
        except json.JSONDecodeError:
            d[field] = [] if field.startswith("allowed_") else {}
    d["enabled"] = bool(d["enabled"])
    d["archived"] = bool(d["archived"])
    return d


def prompt_to_dict(row: sqlite3.Row) -> dict[str, Any]:
    return dict(row)


def consumer_to_dict(row: sqlite3.Row) -> dict[str, Any]:
    d = dict(row)
    d.pop("key_hash", None)  # never expose the hash either
    try:
        d["allowed_rag_ids"] = json.loads(d.get("allowed_rag_ids") or "[]") or []
    except json.JSONDecodeError:
        d["allowed_rag_ids"] = []
    d["stream_allowed"] = bool(d["stream_allowed"])
    d["enabled"] = bool(d["enabled"])
    return d


def audit_to_dict(row: sqlite3.Row) -> dict[str, Any]:
    d = dict(row)
    try:
        d["diff"] = json.loads(d.pop("diff_json") or "{}") or {}
    except json.JSONDecodeError:
        d["diff"] = {}
        d.pop("diff_json", None)
    return d


# ---------------------------------------------------------------- helpers


def next_prompt_version(conn: sqlite3.Connection, rag_id: str) -> int:
    row = conn.execute(
        "SELECT MAX(version) AS v FROM rag_master_prompts WHERE rag_id = ?", (rag_id,)
    ).fetchone()
    return int(row["v"] or 0) + 1


def active_prompt(conn: sqlite3.Connection, rag_id: str) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT * FROM rag_master_prompts WHERE rag_id = ? AND status = 'active'",
        (rag_id,),
    ).fetchone()
