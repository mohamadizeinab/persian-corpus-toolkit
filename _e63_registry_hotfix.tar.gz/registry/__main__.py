"""Run the central RAG registry service (E1).

    python -m drag.registry serve --host 0.0.0.0 --port 8200

Configuration comes from ``REGISTRY_*`` env vars (see :mod:`drag.registry.config`).
"""
from __future__ import annotations

import argparse

from .api import create_app
from .config import load_config


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="rag-registry")
    sub = parser.add_subparsers(dest="cmd", required=True)
    serve = sub.add_parser("serve", help="run the registry HTTP service")
    serve.add_argument("--host", default=None)
    serve.add_argument("--port", type=int, default=None)
    args = parser.parse_args(argv)

    if args.cmd == "serve":
        cfg = load_config()
        if args.host:
            cfg.host = args.host
        if args.port:
            cfg.port = args.port
        app = create_app(cfg)
        app.run(host=cfg.host, port=cfg.port, threaded=True)
        return 0
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
