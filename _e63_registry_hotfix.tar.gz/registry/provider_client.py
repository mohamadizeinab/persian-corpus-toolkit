"""Outbound probe client for registered RAG providers (E1).

Implements the three test actions from the E0 management API:

- ``test-connection`` — GET ``<base_url><healthcheck_endpoint>`` (open on
  provider side, no token needed per RAG_PROVIDER_CONTRACT).
- ``test-auth``       — GET ``<base_url>/v1/models`` with the resolved Bearer
  token; proves the secret reference works without leaking it.
- ``test-retrieval``  — POST ``<base_url>/v1/search`` with a fixed probe
  query. The target collection is caller-supplied, or discovered from the
  provider's **live** collections (GET ``/v1/collections``, Bearer) —
  falling back to ``/v1/sources`` for providers without that endpoint.
  The search body uses the contract field ``collection_id``.

Every probe:
- validates the target URL through the SSRF guard *again* (defense in
  depth);
- disables redirects (stdlib urlopen never follows redirects);
- uses the provider's own ``timeout_ms``;
- returns ``{ok, status, latency_ms, detail}`` with **precise** success or
  error information and **never** echoes the secret (response bodies are
  truncated to 300 chars for diagnostics only).
"""
from __future__ import annotations

import json
import socket
import ssl
import time
import urllib.error
import urllib.request
from dataclasses import dataclass

from . import security
from .security import SSRFConfig, SSRFError, SecretError

DEFAULT_PROBE_TIMEOUT_S = 10.0


@dataclass
class ProbeResult:
    ok: bool
    status: int
    latency_ms: int
    detail: str
    code: str = ""

    def to_dict(self) -> dict:
        out = {"ok": self.ok, "status": self.status,
               "latency_ms": self.latency_ms, "detail": self.detail}
        if self.code:
            out["code"] = self.code
        return out


def _http(method: str, url: str, *, headers: dict | None = None,
          body: dict | None = None, timeout_s: float = DEFAULT_PROBE_TIMEOUT_S) -> tuple[int, str, str]:
    """Minimal stdlib HTTP call, no redirects. Returns (status, body_text, reason)."""
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Accept", "application/json")
    if body is not None:
        req.add_header("Content-Type", "application/json")
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    ctx = ssl.create_default_context() if url.startswith("https") else None
    try:
        with urllib.request.urlopen(req, timeout=timeout_s, context=ctx) as resp:
            return resp.status, resp.read().decode("utf-8", "replace"), ""
    except urllib.error.HTTPError as e:
        try:
            text = e.read().decode("utf-8", "replace") if e.fp else ""
        except Exception:
            text = ""
        return e.code, text, str(e)
    except urllib.error.URLError as e:
        return 0, "", f"unreachable: {e.reason}"
    except (TimeoutError, socket.timeout) as e:
        return 0, "", f"timeout: {e}"


def _truncate(text: str, limit: int = 300) -> str:
    text = (text or "").strip()
    return text if len(text) <= limit else text[:limit] + "…"


def _headers_with_token(token: str) -> dict | None:
    return {"Authorization": f"Bearer {token}"} if token else None


def _check_url(ssrf: SSRFConfig, url: str) -> float:
    """Re-validate a URL (defense in depth) and return the timeout in seconds."""
    ssrf.validate(url)
    return timeout_for(ssrf, url)


def timeout_for(ssrf: SSRFConfig, url: str) -> float:  # pragma: no cover - trivial
    # timeout is applied by callers from the provider's own timeout_ms; this
    # helper exists so probes have a single policy point.
    return DEFAULT_PROBE_TIMEOUT_S


def probe_connection(ssrf: SSRFConfig, base_url: str, healthcheck_endpoint: str,
                     timeout_ms: int) -> ProbeResult:
    t0 = time.monotonic()
    try:
        ssrf.validate(base_url)
    except SSRFError as e:
        return ProbeResult(False, 0, int((time.monotonic() - t0) * 1000),
                           f"ssrf_blocked: {e.detail}", e.code)
    url = base_url.rstrip("/") + "/" + (healthcheck_endpoint or "/health").lstrip("/")
    try:
        ssrf.validate(url)
    except SSRFError as e:
        return ProbeResult(False, 0, int((time.monotonic() - t0) * 1000),
                           f"ssrf_blocked: {e.detail}", e.code)
    timeout_s = max(1.0, min(60.0, (timeout_ms or 10000) / 1000.0))
    status, text, reason = _http("GET", url, timeout_s=timeout_s)
    ms = int((time.monotonic() - t0) * 1000)
    if status == 200:
        return ProbeResult(True, 200, ms, "health endpoint responded 200")
    if status == 0:
        return ProbeResult(False, 0, ms, reason or "connection failed")
    return ProbeResult(False, status, ms,
                       f"unexpected HTTP {status}: {_truncate(text) or reason}")


def probe_auth(ssrf: SSRFConfig, base_url: str, auth_ref: str, timeout_ms: int,
               env_lookup=None, file_lookup=None) -> ProbeResult:
    t0 = time.monotonic()
    try:
        ssrf.validate(base_url)
    except SSRFError as e:
        return ProbeResult(False, 0, int((time.monotonic() - t0) * 1000),
                           f"ssrf_blocked: {e.detail}", e.code)
    try:
        token = security.resolve_secret(auth_ref, env_lookup=env_lookup,
                                        file_lookup=file_lookup)
    except SecretError as e:
        return ProbeResult(False, 0, int((time.monotonic() - t0) * 1000),
                           f"secret_error: {e.detail or e.code}", e.code)
    url = base_url.rstrip("/") + "/v1/models"
    timeout_s = max(1.0, min(60.0, (timeout_ms or 10000) / 1000.0))
    status, text, reason = _http("GET", url, headers=_headers_with_token(token),
                                 timeout_s=timeout_s)
    ms = int((time.monotonic() - t0) * 1000)
    if status == 200:
        return ProbeResult(True, 200, ms, "service token accepted; /v1/models 200")
    if status == 401:
        return ProbeResult(False, 401, ms,
                           "service token rejected by provider (401)")
    if status == 0:
        return ProbeResult(False, 0, ms, reason or "connection failed")
    return ProbeResult(False, status, ms,
                       f"unexpected HTTP {status}: {_truncate(text) or reason}")


def probe_retrieval(ssrf: SSRFConfig, base_url: str, auth_ref: str,
                    query: str = "تفسیر", collection: str | None = None,
                    timeout_ms: int = 10000, env_lookup=None,
                    file_lookup=None) -> ProbeResult:
    t0 = time.monotonic()
    try:
        ssrf.validate(base_url)
    except SSRFError as e:
        return ProbeResult(False, 0, int((time.monotonic() - t0) * 1000),
                           f"ssrf_blocked: {e.detail}", e.code)
    try:
        token = security.resolve_secret(auth_ref, env_lookup=env_lookup,
                                        file_lookup=file_lookup)
    except SecretError as e:
        return ProbeResult(False, 0, int((time.monotonic() - t0) * 1000),
                           f"secret_error: {e.detail or e.code}", e.code)
    headers = _headers_with_token(token)
    base = base_url.rstrip("/")
    timeout_s = max(1.0, min(60.0, (timeout_ms or 10000) / 1000.0))

    target_collection = collection
    if not target_collection:
        # Preferred: live collections (drag: {"ok":true,"collections":[{collection_id,...}]})
        status, text, reason = _http("GET", base + "/v1/collections", headers=headers,
                                     timeout_s=timeout_s)
        if status == 200:
            try:
                data = json.loads(text or "{}")
                cols = data.get("collections") or []
                for c in cols:
                    cid = c.get("collection_id") if isinstance(c, dict) else c
                    if cid:
                        target_collection = str(cid)
                        break
            except (json.JSONDecodeError, AttributeError, TypeError):
                pass
        if not target_collection:
            # Fallback: static source map (drag: {"sources": {source_id: label}})
            status, text, reason = _http("GET", base + "/v1/sources", headers=headers,
                                         timeout_s=timeout_s)
            if status != 200:
                return ProbeResult(False, status or 0, int((time.monotonic() - t0) * 1000),
                                   f"could not list collections (HTTP {status}): {_truncate(text) or reason}",
                                   "no_collections")
            try:
                data = json.loads(text or "{}")
                sources = data.get("sources") or data.get("source_ids") or []
                if isinstance(sources, dict) and sources:
                    target_collection = next(iter(sources.keys()))
                elif isinstance(sources, list) and sources:
                    first = sources[0]
                    target_collection = first.get("source_id") if isinstance(first, dict) else str(first)
            except (json.JSONDecodeError, AttributeError, StopIteration):
                pass
        if not target_collection:
            return ProbeResult(False, 200, int((time.monotonic() - t0) * 1000),
                               "provider exposes no collections to probe against",
                               "no_collections")

    body = {"query": query, "collection_id": target_collection, "top_k": 1}
    status, text, reason = _http("POST", base + "/v1/search", headers=headers,
                                 body=body, timeout_s=timeout_s)
    ms = int((time.monotonic() - t0) * 1000)
    if status == 200:
        hits = 0
        try:
            data = json.loads(text or "{}")
            hits = len(data.get("hits") or data.get("results") or [])
        except json.JSONDecodeError:
            hits = 0
        return ProbeResult(True, 200, ms,
                           f"retrieval ok (collection={target_collection}, hits={hits})")
    if status == 0:
        return ProbeResult(False, 0, ms, reason or "connection failed")
    return ProbeResult(False, status, ms, f"HTTP {status}: {_truncate(text) or reason}")
