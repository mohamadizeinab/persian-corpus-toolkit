# 📚 Persian Corpus Toolkit (پیکره‌ساز فارسی)

ابزار کراول، دیتابیس و پیکره‌سازی برای سایت‌های علمی و محتوایی فارسی — با اکستنشن کروم (Manifest V3)، بکند Flask/SQLite و پایپلاین پیکره.

**Production:** https://corpus.ai.ismc.ir · **Repository:** https://github.com/saber13812002/persian-corpus-toolkit

---

## 🎯 امکانات

| # | قابلیت | وضعیت |
|---|--------|--------|
| 1 | اصطلاح‌نامه `thesaurus.eiis.iki.ac.ir` (فاز۱ لیست + فاز۲ تعاریف کامل) | ✅ فعال |
| 2 | بیانات `farsi.khamenei.ir/speech` (متن/عنوان/تاریخ جلالی/صوت/فیلم) | ✅ فعال |
| 3 | **سیستم پروژه** (v3.5): پروژه برای هر دامنه، نقطه‌های استخراج، کراول قطعه‌قطعه با resume | ✅ فعال (تست واقعی Chrome باقی‌مانده) |
| 4 | سایت‌های نام‌دار با فیلدهای آماده (`tasnim.hamtaa.org` seed شده) | ✅ فعال |
| 5 | داشبورد آنلاین `corpus.ai.ismc.ir/dashboard` (تب «پروژه‌ها» + مرور صفحه‌به‌صفحه + جستجو + Previous/Next + احراز هویت رمز) | ✅ فعال (PCM-04/05/09) |
| 6 | **Word Studio + پایگاه دانش** (PCM-14B): آپلود DOCX ← تبدیل به بلوک/JSON ← ساختار/کیفیت ← job queue با retry + استودیو فارسی `corpus.ai.ismc.ir/dashboard/studio.html` | ✅ فعال (PCM-14B.3) |
| 7 | **Word Factory V0.1 + قرارداد Dump `d-1`** (PCM-14C.3/14C.4): خط لوله DOCX→JSONL ایزوله (policy n-1 ثبت‌شده در manifest m-2) + Dump خوداعتبارسنج و قابل حمل (make-dump/validate-dump/dump-summary) + پذیرش عملی روی CLI واقعی — بدون DB/ES/endpoint | ✅ فعال (26 تست D + پذیرش عملی) |
| 8 | **Work Registry / سلسله‌مراتب کتاب** (PCM-14D): اثر←نسخه←جلد←سند + scopeهای `work/edition/volume` برای متادیتا + resolve لایه‌ای قفل‌شده به anchor + مهاجرت افزایشی idempotent (rollback فقط حذف 3 جدول/6 ستون) | ✅ (10 تست RD + 139/139 — بدون deploy) |
| 8b | **صف پایدار پردازش فایل** (PCM-15): ردیف پایدار per-file (status/stage ایمن/attempts/last_error/duration_ms/out_dir) + `on_stage` callback در Word Factory + pause/resume بچ + summary با شمارنده‌های واقعی DB + ریکاوری crash با حفظ stage | ✅ (9 تست Q + 151/151 — بدون deploy) |
| 8c | **پیکره‌ساز (Corpus Builder) — قرارداد `c-1`** (PCM-16): تبدیل Dumpهای معتبر d-1 به پیکره قابل‌انتقال — دو جریان جدا RAW/NORMALIZED + provenance کامل + dedup بین‌فایلی + آمار واقعی + آرشیو ZIP قطعی + پکیج محلی HF (بدون بارگذاری) + CLI `build-corpus` — بدون DB/ES/شبکه | ✅ (24 تست C + 175/175 — بدون deploy) |
| 8d | **تکمیل UI استودیو** (PCM-17): کارت صف/بچ‌ها (شمارنده‌های زنده + پردازش/توقف/ادامه + polling هوشمند) + کارت رجیستری اثر‌ها (work/edition/volume + اسناد) + endpoint خواندنی `GET /import/batches` + ستون «رجیستری» در جدول اسناد — evidence-based، فقط REST | ✅ (7 تست S + 182/182 — بدون deploy) |
| 8e | **قرارداد API + CI + کلاینت** (PCM-19): تست‌های قرارداد CT-01..CT-06 (OpenAPI spec ↔ app زنده) + GitLab CI test-only (`.gitlab-ci.yml`) + چک‌کن OpenAPI + نمونه کلاینت REST (فقط stdlib) | ✅ (18 تست CT + 200/200 — بدون deploy) |
| 8f | **Tasnim Corpus Factory — قرارداد `c-20.3`** (PCM-20.3): خط لوله «تفسیر تسنیم همتا» — Work→Edition→Volume→Page با شناسه‌های قطعی + RAW/NORMALIZED جدا + flag به‌جای حذف + QC + idempotency/دترمینیسم + دیتاست‌های 1/10/50/90/100% (`stratified-even-blocks`) + diff/manifest/registry + خروجی Dump سازگار با ai-dump-builder — بدون DB/ES/شبکه | ✅ (16 تست T + 200/200 — بدون deploy) |
| 8g | **پذیرش واقعی Tasnim — زنجیره end-to-end** (PCM-20.4): snapshot واقعی 45,844 صفحه (SHA verify + GATE 1.5 truncation) → پیکره canonical v0001 → 6 دیتاست نسخه‌شده (شامل 1 جلد + fixture افزایشی) → 3 خروجی Dump → **3 build واقعی ai-dump-builder** (mock embedding؛ Neo4j/شبکه درگیر نشد) + زنجیره‌ی manifest/provenance + 216 تست سبز | ✅ (acceptance PASS — بدون deploy) |
| 9 | پایپلاین پیکره + دیتaset + آپلود HuggingFace | ✅ در دسترس |
| 10 | ایندکسر RAG | 🚧 در دست توسعه |

### سیستم پروژه (هسته v3.5)

به‌جای «کراول یکسره»، یک **پروژه** (یک کتاب/سایت) تعریف می‌شود:

1. در Popup: نام پروژه + دامنه (خودکار از تب فعال) → «ساختن از این صفحه»
2. «انتخاب و ویرایش» → پنل روی صفحه → کلیک روی المنت‌ها = تعریف **نقطه** (tag + selector + transform)
3. «آزمایش و شروع» → حلقه خواندن: هر دقیقه N صفحه (N=1..12) با `chrome.alarms`
4. هر صفحه با **SHA-256** dedup می‌شود؛ شمارنده‌های saved/skipped/failed تجمعی‌اند
5. **Resume:** موقعیت خواندن در `cursor_url` ذخیره می‌شود — بعد از هر قطعی (بستن کروم، refresh، 2 صفحه خالی) از آخرین کراول ادامه می‌یابد
6. Pause خودکار بعد از 2 صفحه خالی پشت‌سرهم؛ resume با شروع مجدد

---

## 🏗 معماری

```
┌────────────────────────────────────────────────────────┐
│  Chrome Extension (Manifest V3)                        │
│  • popup.js/popup.html  — UI پروژه و آمار             │
│  • content_picker.js    — پنل روی صفحه: انتخاب نقطه   │
│  • background.js        — حلقه خواندن دقیقه‌ای (alarm)  │
│  • content_thesaurus.js / content_khamenei.js          │
├────────────────────────────────────────────────────────┤
│  Flask Backend (پورت ۵۰۵۵، SQLite WAL)                │
│  • server.py      — API اصلی + فاز۱/۲ + harvest      │
│  • projects.py    — پروژه/نقطه/صفحه/گزارش ★          │
│  • auth.py        — احراز هویت داشبورد (scrypt+cookie) │
│  • dashboard_api.py — API خواندنی داشبورد ★           │
│  • knowledge_api.py — ★ Word Studio/پایگاه دانش (PCM-14B)│
│  • sites.py       — سایت‌های نام‌دار + فیلدها ★      │
│  • sciences.py    — ۱۳ علم اصطلاح‌نامه               │
│  • factory/       — ★ Word Factory: DOCX→JSONL + Dump d-1│
│                   + Corpus Builder c-1 (PCM-16)         │
│  • 11 test files — 200 تست (api/projects/dashboard/    │
│                     knowledge_api/factory/dump/work/    │
│                     queue/corpus_builder/studio_api/    │
│                     api_contract — قرارداد OpenAPI)    │
├────────────────────────────────────────────────────────┤
│  Corpus Pipeline (corpus/)                             │
│  • build_corpus.py / build_dataset.py / pipeline.py    │
│  • upload_to_hf.py — آپلود به 🤗 HuggingFace          │
│  • tasnim/ — ★ Tasnim Corpus Factory + acceptance      │
│                  (PCM-20.3/20.4 — بدون DB/ES/شبکه)     │
├────────────────────────────────────────────────────────┤
│  RAG Indexer (در دست توسعه)                           │
│  • Embedding با GPU، تخمین زمان، resume، anti-ban      │
└────────────────────────────────────────────────────────┘
```

### ساختار پروژه

```
persian-corpus-toolkit/
├── backend/
│   ├── server.py            # API اصلی (فاز۱/۲، harvest، khamenei)
│   ├── projects.py          # ★ سیستم پروژه (v3.5)
│   ├── auth.py              # ★ احراز هویت داشبورد (PCM-09)
│   ├── dashboard_api.py     # ★ API خواندنی داشبورد (PCM-04)
│   ├── knowledge_api.py     # ★ Word Studio + پایگاه دانش (PCM-14B)
│   ├── factory/             # ★ Word Factory: DOCX→JSONL (CLI + policy n-1 + dump.py)
│   ├── sites.py             # ★ سایت‌ها و فیلدهای آماده
│   ├── sciences.py          # ۱۳ علم
│   ├── pct_test_support.py  # ★ harness ایزوله (DB موقت مشترک)
│   ├── test_api.py          # ۸ تست
│   ├── test_projects.py     # ۹ تست جریان پروژه
│   ├── test_dashboard.py    # ۲۲ تست (auth A01-A08 + D01-D07 + صفحات P01-P07)
│   ├── test_knowledge_api.py# ★ ۴۰ تست KB-01..KB-14
│   ├── test_word_factory.py # ★ ۲۷ تست WF-01..WF-13 + on_stage
│   ├── test_dump.py         # ★ ۲۶ تست D01..D15 (Dump d-1 — PCM-14C.3)
│   ├── test_work_registry.py# ★ ۱۰ تست RD-01..RD-07 (Work Registry — PCM-14D)
│   ├── test_api_contract.py # ★ ۱۸ تست CT-01..CT-06 (قرارداد OpenAPI↔app — PCM-19)
│   ├── requirements.txt
│   ├── Dockerfile
│   └── thesaurus.db         # (gitignored)
├── extension/
│   ├── manifest.json        # v3.5
│   ├── popup.html / popup.js
│   ├── background.js        # service worker + حلقه minute-loop
│   ├── content_picker.js    # ★ پنل انتخاب نقطه روی صفحه
│   ├── content_thesaurus.js / content_khamenei.js
│   ├── shared.js
│   ├── test_popup.js        # ۸ تست UI (node)
│   └── icons/
├── corpus/                  # پایپلاین پیکره و دیتاست
│   └── tasnim/              # ★ Tasnim Corpus Factory: audit/build/dataset/dump/diff (PCM-20.3/20.4)
├── dashboard/               # داشبورد (تب‌های اصلی + «پروژه‌ها» + studio.html + overlay ورود)
├── data/                    # (gitignored) store پایدار: data/knowledge/{files,out} (PCM-14B)
│                            #   + data/tasnim/pcm20_4/ (خروجی‌های پذیرش — gitignored)
├── deploy/                  # nginx vhost + systemd + اسکریپت‌های دپلوی PCM
├── docs/                    # project-dashboard.md · dashboard-authentication.md ·
│                            #   WORD-FACTORY-USER-GUIDE.md · WORD-STUDIO-KNOWLEDGE-GUIDE.md ·
│                            #   PCM-14C.3-DUMP-CONTRACT.md · PCM-12/13 ·
│                            #   PCM-20.3-TASNIM-FORFACTORY.md · PCM-20.4-TASNIM-ACCEPTANCE.md
├── docker-compose.yml       # backend محلی روی 127.0.0.1:5055
├── AGENTS.md                # قواعد سخت دپلوی/مهاجرت/رمز
└── گزارش-وضعیت-پروژه.md / گزارش-PCM-0X.md
```

---

## 🚀 نصب و راه‌اندازی

### پیش‌نیازها
- Python 3.10+ (تست‌شده روی 3.12/3.14)
- Google Chrome (برای اکستنشن)
- Git

### 1. دریافت

```bash
git clone https://github.com/saber13812002/persian-corpus-toolkit.git
cd persian-corpus-toolkit
```

### 2. بکند (دو روش)

```bash
# روش A — مستقیم
cd backend
pip install -r requirements.txt
python server.py            # ← http://127.0.0.1:5055

# روش B — Docker (مطابق Production)
docker compose up -d --build
```

### 3. اکستنشن کروم

1. `chrome://extensions` ← **Developer mode** روشن
2. **Load unpacked** ← پوشه `extension/`
3. صفحه سایت هدف را باز کن و روی آیکون اکستنشن کلیک کن
4. برای سیستم پروژه: نام پروژه بنویس ← «ساختن از این صفحه» ← «انتخاب و ویرایش» (پنل روی صفحه) ← «آزمایش و شروع»

> برای تست محلی، ثابت `BACKEND` در `popup.js`، `background.js` و `content_picker.js` را به `http://127.0.0.1:5055` تغییر بده. در حالت Production همه‌جا `https://corpus.ai.ismc.ir` است.

### 4. ساخت پیکره

```bash
cd corpus
python pipeline.py          # خروجی در corpus/output/
python upload_to_hf.py --token hf_... --username ...
```

---

## 📊 API Endpoints (پورت 5055)

### سیستم پروژه (v3.5)

| Endpoint | Method | توضیح |
|---|---|---|
| `/api/projects?host=…` | GET | فهرست پروژه‌ها (فیلتر بر اساس دامنه) |
| `/api/projects` | POST | ساخت پروژه `{name, host, start_url, next_mode, next_param, next_step, pages_per_minute}` |
| `/api/projects/<id>` | GET/POST | مشاهده / ویرایش |
| `/api/projects/<id>/points` | POST/DELETE | تعریف/ویرایش/اعاده‌نام/حذف نقطه |
| `/api/projects/<id>/pages` | POST | ذخیره صفحه `{url, values}` — dedup با SHA-256 |
| `/api/projects/<id>/report` | POST | گزارش اجرا `{saved, skipped, failed, cursor_url, status}` |

### داشبورد (PCM-04/09 — 🔒 نیاز به ورود)

| Endpoint | Method | توضیح |
|---|---|---|
| `/api/auth/login` | POST | ورود `{password}` → cookie `pct_session` (HttpOnly/Secure/SameSite=Lax) |
| `/api/auth/logout` | POST | باطل‌کردن session |
| `/api/auth/status` | GET | `{auth_enabled, authenticated}` |
| `/api/dashboard/projects` | GET | فهرست پروژه‌ها — جستجو/فیلتر/status/مرتب‌سازی/صفحه‌بندی سمت سرور |
| `/api/dashboard/projects/<id>` | GET | جزئیات: فیلدها، pages_summary، values_sample آخرین صفحه |
| `/api/dashboard/projects/<id>/pages` | GET | **PCM-05** فهرست صفحات — جستجو (URL/متن فیلدها)، sort، صفحه‌بندی، prev/next |
| `/api/dashboard/projects/<id>/pages/<page_id>` | GET | **PCM-05** جزئیات صفحه — values، position، JSON خام، field_errors |

### Word Studio / پایگاه دانش (PCM-14B — 🔒 نیاز به ورود)

| Endpoint | Method | توضیح |
|---|---|---|
| `/api/knowledge/collections` | GET/POST | فهرست (جستجو/فیلتر موضوع/صفحه‌بندی) / ساخت `{name, slug, subject_id}` |
| `/api/knowledge/collections/<id>` | GET/PATCH | جزئیات / ویرایش |
| `/api/knowledge/collections/<id>/documents` | POST/GET | آپلود DOCX (multipart) / فهرست اسناد |
| `/api/knowledge/collections/<id>/documents/<doc_id>` | DELETE | جداکردن سند |
| `/api/knowledge/collections/<id>/builds` | GET | buildها (V0.1: ES غیرفعال) |
| `/api/knowledge/documents/<doc_id>` | GET | جزئیات سند |
| `/api/knowledge/documents/<doc_id>/process` | POST | (باز)پردازش با Word Factory — idempotent + retry |
| `/api/knowledge/documents/<doc_id>/approve` | POST | تأیید (فقط parsed/needs_review) |
| `/api/knowledge/documents/<doc_id>/structure|quality|blocks|file` | GET | ساختار / کیفیت / بلوک‌ها (صفحه‌بندی) / فایل اصلی |
| `/api/knowledge/subjects` | GET | ۱۳ علم |
| `/api/knowledge/import/batches(…)` | POST/GET | ثبت/پردازش batch (V0.1: registration) |
| `/api/knowledge/jobs` | GET | job queue |
| `/api/knowledge/metadata/fields(…)` / `values(…)` | GET/POST/PATCH/DELETE | متادیتای مجموعه‌ای (scope: collection/batch/document/work/edition/volume) |
| `/api/knowledge/works(…)` / `editions(…)` / `volumes(…)` | GET/POST/PATCH | ★ Work Registry: سلسله‌مراتب اثر/نسخه/جلد (PCM-14D) |
| `/api/knowledge/metadata/resolve` | GET | ★ resolve لایه‌ای: document>volume>edition>work>collection>field_default |
| `/api/knowledge/compatibility` | GET | وضعیت ES (`NOT VERIFIED` در V0.1) |

سند کامل: [docs/project-dashboard.md](docs/project-dashboard.md) · [docs/dashboard-authentication.md](docs/dashboard-authentication.md) · [docs/WORD-STUDIO-KNOWLEDGE-GUIDE.md](docs/WORD-STUDIO-KNOWLEDGE-GUIDE.md) · [docs/WORD-FACTORY-USER-GUIDE.md](docs/WORD-FACTORY-USER-GUIDE.md) · [docs/PCM-14D-WORK-REGISTRY.md](docs/PCM-14D-WORK-REGISTRY.md)

### سایت‌ها

| Endpoint | Method | توضیح |
|---|---|---|
| `/api/sites` | GET | فهرست سایت‌های نام‌دار + فیلدها |
| `/api/sites/match?host=…` | GET | فیلدهای آماده یک سایت |
| `/api/captures` | POST | ذخیره و dedup صفحات عمومی |

### فازهای کلاسیک

| Endpoint | Method | توضیح |
|---|---|---|
| `/api/phase1/seed-batch`, `/api/phase2/next-batch`, `/api/phase2/complete` | POST | فاز۱/۲ اصطلاح‌نامه |
| `/api/thesaurus/elastic-harvest(+status)` | GET/POST | harvest سمت سرور (async + resume) |
| `/api/khamenei/*` | — | seed/submit/reset/stats/pending |
| `/api/stats`, `/api/pipeline/status`, `/api/queue` | GET | آمار |

---

## 🗄️ دیتابیس

`backend/thesaurus.db` (SQLite، WAL mode، gitignored)

| جدول | توضیح |
|---|---|
| `crawl_queue`, `crawled_data` | صف و داده‌های کلاسیک (content hash) |
| `projects` | ★ پروژه‌ها + `cursor_url` (نقطه resume) + شمارنده‌ها |
| `project_points` | ★ نقطه‌های استخراج (tag + source + selector + transform) |
| `project_pages` | ★ صفحات ذخیره‌شده (values_json + SHA-256) |
| `sites`, `site_fields` | سایت‌های نام‌دار و فیلدهای آماده |
| `captures` | captures عمومی |
| `auth_meta`, `auth_sessions`, `auth_rate` | ★ احراز هویت داشبورد (scrypt-hash، sessionهای ۷روزه، rate-limit) |
| `knowledge_collections`, `knowledge_collection_documents`, `knowledge_document_metadata_fields/values` | ★ مجموعه‌ها + اسناد + متادیتا (PCM-14B) |
| `knowledge_works`, `knowledge_editions`, `knowledge_volumes` | ★ Work Registry: اثر/نسخه/جلد (PCM-14D، additive + backfill) |
| `knowledge_jobs`, `knowledge_import_batches`, `knowledge_index_builds` | ★ job queue + batch + build (V0.1) |
| `knowledge_schema_version` | نسخه اسکیمای knowledge (additive migration) |

جدول‌های جدید **خودکار** و **additive** ساخته می‌شوند (migration امن برای DBهای قدیمی).

### بک‌آپ و بازیابی

```bash
sqlite3 backend/thesaurus.db ".backup backups/thesaurus_$(date +%Y%m%d_%H%M%S).db"
sqlite3 backups/thesaurus_xxx.db "PRAGMA integrity_check;"   # تأیید: ok
cp backups/thesaurus_20260802.db backend/thesaurus.db       # بازیابی
```

### Upsert هوشمند

با **content hash** (SHA-256): آیتم جدید → INSERT · تکراری با همین محتوا → SKIP · تکراری با محتوا تغییرکرده → UPDATE (version+1).

---

## 🧪 تست‌ها

```bash
cd backend && python -m unittest test_api test_projects test_dashboard -v     # 39/39 (هسته)
cd backend && python -m unittest test_knowledge_api -v                        # 40/40 (PCM-14B)
cd backend && python -m unittest test_word_factory -v                         # 27/27 (PCM-14B + on_stage PCM-15)
cd backend && python -m unittest test_dump -v                                 # 26/26 (Dump d-1 — PCM-14C.3)
cd backend && python -m unittest test_work_registry -v                       # 10/10 (Work Registry — PCM-14D)
cd backend && python -m unittest test_queue -v                               # 9/9 (صف فایل — PCM-15)
cd backend && python -m unittest test_corpus_builder -v                       # 24/24 (پیکره‌ساز c-1 — PCM-16)
cd backend && python -m unittest test_studio_api -v                           # 7/7 (استودیو PCM-17)
cd backend && python -m unittest test_api_contract -v                         # 18/18 (قرارداد OpenAPI — PCM-19)
cd backend && python -m unittest test_api test_projects test_dashboard \
  test_knowledge_api test_word_factory test_dump test_work_registry test_queue \
  test_corpus_builder test_studio_api test_api_contract  # 200/200 (کل)
cd extension && node test_popup.js                                            # 8/8
node --check extension/popup.js extension/background.js extension/content_picker.js
node -e "JSON.parse(require('fs').readFileSync('extension/manifest.json'))"
```

قبل از هر commit، همه‌ی مجموعه‌ها باید سبز باشند. همه‌ی ماژول‌ها از `pct_test_support`
(DB موقت مشترک) استفاده می‌کنند — ترتیب/ترکیب ماژول‌ها مهم نیست (PCM-12.3).

---

## 🏭 استقرار Production (corpus.ai.ismc.ir)

حقیقت‌های تأییدشده سرور (ممیزی PCM-03 — ۱۴۰۵/۰۸/۰۲):

| مورد | مقدار |
|---|---|
| سرور | `s52` (`172.20.1.52`) — SSH واقعی روی **پورت 22** (`ssh saber@172.20.1.52`) |
| ⚠️ پورت 2222 | **GitLab CE** است (کانتینر `gitlab` با map 2222→22)، **نه** SSH هاست — در `~/.ssh/config` برای SSH استفاده نشود |
| مسیر استقرار | `/home/saber/saberprojects/persian-corpus-toolkit` (کپی کد؛ **نه** git repo — کد از `origin/main` منتقل می‌شود) |
| Compose / کانتینر | سرویس `backend` فقط؛ کانتینر `persian-corpus-toolkit-backend-1`؛ image `persian-corpus-toolkit-backend` |
| پورت | `127.0.0.1:5055` (nginx `corpus.ai.ismc.ir` جلوی آن است) |
| DB | bind-mount: `./backend/thesaurus.db → /data/thesaurus.db` (SQLite WAL — فایل پایدار، نه volume نام‌دار) |

**داشبورد + احراز هویت (PCM-04/09 — از ۱۴۰۵/۰۸/۰۱):**
- داشبورد: `https://corpus.ai.ismc.ir/dashboard/` — tab «📁 پروژه‌ها» (فهرست + صفحه‌بندی + جزئیات)
- **PCM-05:** کارت «📄 صفحات» در جزئیات هر پروژه — مرور صفحه‌به‌صفحه، جستجو در URL/متن فیلدها،
  sort/صفحه‌بندی، Previous/Next هم‌راستای ترتیب لیست، JSON خام هر صفحه + کپی (فقط خواندنی، بدون مهاجرت schema)
- **Word Studio (PCM-14B.3):** `https://corpus.ai.ismc.ir/dashboard/studio.html` —
  مجموعه‌ها/کتاب‌ها/جزئیات (ساختار، کیفیت، بلوک‌ها) + job queue؛ آپلود DOCX ←
  پردازش با Word Factory ← approve. راهنما: [docs/WORD-STUDIO-KNOWLEDGE-GUIDE.md](docs/WORD-STUDIO-KNOWLEDGE-GUIDE.md)
- ورود: `POST /api/auth/login` با رمز؛ cookie `pct_session` (HttpOnly/Secure/SameSite=Lax)
- رمز: **فقط** در `.env` سرور (gitignored، chmod 600) — در DB به‌صورت scrypt-hash؛ هرگز در کد/Git/لاگ
- APIهای نوشتاری اکستنشن (`/api/projects*`) **باز می‌مانند** → کراول زنده هرگز با ورود داشبورد قطع نمی‌شود
- اگر رمزی seed نشده باشد (محیط توسعه)، APIهای داشبورد بدون ورود باز می‌مانند

**روند به‌روزرسانی (تأییدشده در PCM-03/04):**
1. بکاپ: `deploy/pcm04_deploy.sh` → `/home/saber/backups/thesaurus-<TS>.db` + `PRAGMA integrity_check`
2. سشن‌شات کد: tar کل پوشه استقرار (به‌جز DB) → `/home/saber/backups/pct-deploy-<TS>.tar.gz`
3. تضمین `.env` (رمز داشبورد، chmod 600) — فقط در سرور، هرگز در Git
4. انتقال کد `origin/main` به پوشه استقرار (DB در tar نباشد)
5. `docker compose build backend && docker compose up -d backend` — **فقط recreate backend؛ بدون `down`**
6. smoke test: health + auth (401 بدون cookie / 200 با cookie) + API اکستنشن باز + integrity_check

**قوانین:**
- ⛔ `docker-compose down` ممنوع — فقط `up -d backend` (recreate)
- ⛔ حذف هرگز: فایل `thesaurus.db`، volumeها، یا هر سرویس نامرتبط (سرور 40+ کانتینر دیگر دارد)
- همیشه **قبل** از هر استقرار: بکاپ SQLite + `integrity_check`
- Rollback: extract سشن‌شات کد + `docker compose build backend && up -d backend`؛ بازیابی DB از `/home/saber/backups/`
- اسکیمای `projects` **additive** است (جدول جدید، دست‌نخورده روی جداول قدیمی)

جزئیات کامل ممیزی، بکاپ‌ها و rollback: [گزارش-PCM-03.md](گزارش-PCM-03.md) بخش ۳–۴ · برنامه اولیه: [گزارش-PCM-02.md](گزارش-PCM-02.md) بخش ۳

---

## 🛠️ راهنمای توسعه‌دهنده

### افزودن سایت/دامنه جدید
- سایت «نام‌دار»: در `backend/sites.py` رکورد + فیلدهای پیش‌فرض + تست در `test_api.py`
- سایت دلخواهی: بدون کد — از popup ساخته می‌شود و نقطه‌ها در پنل تعریف می‌شوند
- transform جدید: در `content_picker.js` (استخراج) + `projects.py` (معتبرسازی) + تست

### رفع مشکل CORS
در `server.py` از `flask-cors` استفاده شده (origins باز برای `chrome-extension://*`).

### Debug
```bash
python server.py                          # لاگ بکند در stdout
# اکستنشن: F12 → Console → filter: [Crawler]
# کنسول popup: راست‌کلیک روی popup → Inspect → تب Network
sqlite3 backend/thesaurus.db "SELECT COUNT(*) FROM project_pages"
```

### وضعیت‌های باز (backlog)
- رفع `sleep` ثابت و `waitComplete` در `background.js` (B1/B2 گزارش PCM-01)
- `corpus/build_project_corpus.py` (خروجی پروژه به txt/jsonl)
- RAG indexer · lint (CI unittest در `.gitlab-ci.yml` فعال شد — PCM-19) · یکپارچه‌سازی ثابت `BACKEND` در `shared.js`

### نقشه‌ی راه (ترتیب اجرا)

| فاز | وضعیت |
|-----|-------|
| PCM-01 رفع «پروژه ساخته نمی‌شود» | ✅ |
| PCM-02 برنامه و ممیزی | ✅ |
| PCM-03 deploy + ممیزی production | ✅ |
| PCM-04 تب پروژه‌ها (فهرست/جزئیات/صفحه‌بندی) + PCM-09 auth | ✅ |
| PCM-05 مرور صفحه‌به‌صفحه / آیتم‌به‌آیتم | ✅ |
| PCM-06 نمای آمار واقعی | ⏳ |
| PCM-07 ناوبری دوسویه + checkpoint/resume + کنترل Start/Pause/Resume/Retry | ⏳ |
| PCM-08 موتور transform + reprocess | ⏳ |
| PCM-10 health/metrics + داشبورد Grafana (زیرساخت موجود s52) | ⏳ |
| PCM-12 ممیزی معماری + بلوپرینت Book Factory → Knowledge → RAG | ✅ (مستندات — بدون کد عملیاتی) |
| PCM-13+ مسیر V0.1→V1.0: Word → JSON → ES test index → Queue → RAG API → Registries → LiteLLM → SuperRAG → Research شبانه | 📋 طراحی‌شده (فقط طرح؛ **هنوز پیاده‌سازی نشده**) |
| PCM-12.2 آزمون پذیرش قابلیت‌ها + ممیزی دسترسی پس از مهاجرت s52 | ✅ (مستندات + آزمون خواندنی — بدون کد عملیاتی) |
| PCM-12.3 اصلاح ریشه‌ای test isolation (F-01) + ممیزی امنیتی Grafana | ✅ (test-harness + docs — بدون تغییر production، بدون deploy) |
| **PCM-14B Word Factory** DOCX→JSON block (CLI، بدون DB/endpoint) | ✅ (۲۴ تست WF) |
| **PCM-14B.2** Knowledge Base: schema v1→v2 + store پایدار (data/knowledge) | ✅ (روی s52) |
| **PCM-14B.3** API Knowledge + Word Studio (studio.html) + job queue + deploy | ✅ (روی s52، ۴۰ تست KB + 103 کل) |
| **PCM-14C.3** قرارداد رسمی Dump `d-1` + manifest `m-2` (ثبت policy نرمال‌سازی) + CLI make-dump/validate-dump/dump-summary | ✅ (26 تست D + 129 کل — بدون تغییر production، بدون deploy) |
| **PCM-14C.4** پذیرش عملی قرارداد Dump روی CLI واقعی (`deploy/pcm14c4_dump_acceptance.py`: WF×2 + make/validate/summary + کپی + خرابی عمدی + سازگاری m-1 + تکرارپذیری 12/12) | ✅ (ACCEPTANCE PASS — بدون تغییر production، بدون deploy) |
| **PCM-14D** Work Registry: سلسله‌مراتب اثر←نسخه←جلد + scopeهای work/edition/volume متادیتا + resolve لایه‌ای + OpenAPI | ✅ (10 تست RD + 139/139 — بدون deploy؛ سند: docs/PCM-14D-WORK-REGISTRY.md) |
| **PCM-15** صف پایدار پردازش فایل: knowledge_file_queue + queue_control + `on_stage` در factory + pause/resume/summary + ریکاوری crash با حفظ stage + سازگاری Dump d-1 | ✅ (9 تست Q + 151/151 — بدون deploy؛ سند: docs/PCM-15-FILE-QUEUE.md) |
| **PCM-16** پیکره‌ساز از Dumpهای معتبر d-1: قرارداد c-1 — جریان‌های جدا RAW/NORMALIZED + provenance + dedup + آرشیو قطعی + پکیج محلی HF + CLI build-corpus (بدون DB/ES/شبکه) | ✅ (24 تست C + 175/175 — بدون deploy؛ سند: docs/PCM-16-CORPUS-BUILDER.md) |
| **PCM-17** تکمیل UI استودیو: کارت صف/بچ‌ها + کارت رجیستری اثر‌ها + `GET /import/batches` (افزایشی) + ستون رجیستری اسناد — evidence-based، فقط REST | ✅ (7 تست S + 182/182 — بدون deploy؛ سند: docs/PCM-17-STUDIO-UI.md) |
| **PCM-18** ممیزی observability روی s52: اسکریپت خواندنی + گزارش (اجرای s52 مسدود — host unreachable، 5 timeout) | ✅ (اسکریپت + گزارش — اجرای s52 در انتظار دسترسی) |
| **PCM-19** قرارداد API: تست‌های CT-01..CT-06 (200 کل) + به‌روزرسانی README/AGENTS/OpenAPI + GitLab CI (test-only) + نمونه کلاینت REST + چک‌کن OpenAPI | ✅ (18 تست CT + 200/200 — بدون deploy؛ سند: docs/openapi/README.md) |

جزئیات معماری و نقشه‌ی راه نسخه‌ای (V0.1..V1.0): مستندات PCM-12 در [docs/](docs/) — `PCM-12-AUDIT.md` (وضعیت واقعی)، `PCM-12-ARCHITECTURE.md` (طراحی S2..S9)، `PCM-12-PRD.md` (الزامات)، `PCM-12-ROADMAP.md` (ترتیب اجرا)، `PCM-12-DATA-CONTRACTS.md` (schema/API/Prompt)، `PCM-12-AGENT-HANDOFF.md` (تصمیم‌ها و مرزها)، `PCM-12-ACCEPTANCE-REPORT.md` (گزارش آزمون پذیرش ۲۰ سناریو + ممیزی دسترسی s52)، `PCM-12-ACCEPTANCE-CHECKLIST.md` (چک‌لیست تأیید کاربری با Chrome) و `PCM-12.3-TEST-ISOLATION.md` (رفع ریشه‌ای F-01 + ممیزی امنیتی Grafana).

> ⚠️ قابلیت‌های PCM-13 به بعد (Book Factory، RAG، Registries، SuperRAG) **فقط طراحی‌شده** هستند و در production فعال **نیستند**.

جزئیات بیشتر: [گزارش-وضعیت-پروژه.md](گزارش-وضعیت-پروژه.md) و [گزارش-PCM-02.md](گزارش-PCM-02.md)

---

## 📝 License

CC BY-NC-SA 4.0 — استفاده پژوهشی و آموزشی
